export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  phone?: string;
  activeMasjidId?: string;
  createdAt: any; // Firestore Timestamp or Date ISO string
}

export interface Masjid {
  id: string;
  name: string;
  area: string;
  createdBy: string;
  createdAt: any;
  clearPassword?: string;
}

export interface FinanceEntry {
  id: string;
  type: "income" | "expense";
  date: string; // YYYY-MM-DD
  category: string; // Tamil category name
  amount: number;
  description?: string;
  createdAt: any;
  month: string; // YYYY-MM
  year: string; // YYYY
  quarter: string; // Q1/Q2/Q3/Q4-YYYY
  masjidId: string;
  userId: string;
}

export interface TempCategory {
  id: string;
  name: string;
  type: "income" | "expense";
  month: string; // YYYY-MM
  createdAt: any;
  masjidId: string;
}

export type Tab = "entry" | "statement" | "category";

import React, { useState, useEffect } from "react";
import { UserProfile, Masjid, FinanceEntry, TempCategory, Tab } from "./types";
import { isFirebaseConfigured, db, auth, OperationType, handleFirestoreError } from "./firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import {
  collection,
  onSnapshot,
  query,
  where,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  addDoc,
  serverTimestamp,
  deleteDoc,
  getDocs,
} from "firebase/firestore";
import Loader from "./components/Loader";
import LoginPage from "./components/LoginPage";
import MasjidSetup from "./components/MasjidSetup";
import EntryTab from "./components/EntryTab";
import StatementTab from "./components/StatementTab";
import CategoryTab from "./components/CategoryTab";
import { PlusCircle, BarChart, Tag, Building2, LogOut, RefreshCw, RefreshCwOff, Sun, Moon, Smartphone, Github, X, Check, Settings, Key, Trash2, Info, Lock, Mail, Eye, EyeOff } from "lucide-react";

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const persisted = localStorage.getItem("masjid_user_profile");
      return persisted ? JSON.parse(persisted) : null;
    } catch {
      return null;
    }
  });

  // State for App Download / GitHub Pages helper modal
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [installTab, setInstallTab] = useState<"apk" | "github">("apk");

  // States for Settings, Password Setup & All Clear operations
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [settingsErr, setSettingsErr] = useState("");
  const [settingsSuccess, setSettingsSuccess] = useState("");
  const [currentPasswordInput, setCurrentPasswordInput] = useState("");
  const [newPasswordInput, setNewPasswordInput] = useState("");
  const [confirmNewPasswordInput, setConfirmNewPasswordInput] = useState("");
  const [showPasswordText, setShowPasswordText] = useState(false);
  
  // States for Forget Password workflow
  const [isForgotPwOpen, setIsForgotPwOpen] = useState(false);
  const [forgotEmailInput, setForgotEmailInput] = useState("");
  const [retrievedPassword, setRetrievedPassword] = useState("");

  // States for database clearing confirm
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);
  const [clearConfirmPasswordInput, setClearConfirmPasswordInput] = useState("");

  // State for browser PWA prompt trigger
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallPwaBtn, setShowInstallPwaBtn] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallPwaBtn(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstallPWA = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setDeferredPrompt(null);
        setShowInstallPwaBtn(false);
      }
    } else {
      alert("இந்த செயலி ஏற்கனவே நிறுவப்பட்டது அல்லது உங்கள் உலாவி இந்த செயல்பாட்டை ஆதரிக்கவில்லை. அலைபேசி உலாவியில் (Chrome, Safari) 'Add to Home Screen' பயன்படுத்தவும்.");
    }
  };

  const [activeMasjidId, setActiveMasjidId] = useState<string | null>(() => {
    return localStorage.getItem("masjid_active_id") || null;
  });

  const [masjids, setMasjids] = useState<Masjid[]>(() => {
    try {
      const persisted = localStorage.getItem("masjid_list");
      return persisted ? JSON.parse(persisted) : [];
    } catch {
      return [];
    }
  });

  const [entries, setEntries] = useState<FinanceEntry[]>(() => {
    try {
      const persisted = localStorage.getItem("masjid_entries");
      return persisted ? JSON.parse(persisted) : [];
    } catch {
      return [];
    }
  });

  const [tempCategories, setTempCategories] = useState<TempCategory[]>(() => {
    try {
      const persisted = localStorage.getItem("masjid_temp_cats");
      return persisted ? JSON.parse(persisted) : [];
    } catch {
      return [];
    }
  });

  const [activeTab, setActiveTab] = useState<Tab>("entry");
  const [loading, setLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"live" | "local">("local");

  // Modern Theme Toggle hook
  const [theme, setTheme] = useState<"light" | "dark">(() => {
    return (localStorage.getItem("masjid_theme") as "light" | "dark") || "light";
  });

  useEffect(() => {
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("masjid_theme", theme);
  }, [theme]);

  // 1. Authenticated User Observer
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      setSyncStatus("local");
      return;
    }

    setLoading(true);
    const unsubscribe = onAuthStateChanged(auth, async (fbUser: any) => {
      if (fbUser) {
        setSyncStatus("live");
        // Pull/Verify user profile in Firestore
        try {
          const userDocRef = doc(db, "users", fbUser.uid);
          const userDocSnap = await getDoc(userDocRef);

          let profile: UserProfile;
          if (userDocSnap.exists()) {
            const data = userDocSnap.data();
            profile = {
              uid: fbUser.uid,
              name: data.name,
              email: data.email,
              phone: data.phone || "",
              activeMasjidId: data.activeMasjidId || "",
              createdAt: data.createdAt,
            };
          } else {
            // Create user profile on-the-fly
            profile = {
              uid: fbUser.uid,
              name: fbUser.displayName || "அறியப்படாத பயனர்",
              email: fbUser.email || "",
              phone: fbUser.phoneNumber || "",
              activeMasjidId: "",
              createdAt: new Date().toISOString(),
            };
            await setDoc(userDocRef, {
              name: profile.name,
              email: profile.email,
              phone: profile.phone,
              activeMasjidId: "",
              createdAt: profile.createdAt,
            });
          }

          setCurrentUser(profile);
          localStorage.setItem("masjid_user_profile", JSON.stringify(profile));

          if (profile.activeMasjidId) {
            setActiveMasjidId(profile.activeMasjidId);
            localStorage.setItem("masjid_active_id", profile.activeMasjidId);
          }
        } catch (error) {
          console.warn("Firestore user sync failed (operating offline):", error);
          setSyncStatus("local");

          // Resilient fallback to localStorage cache or temporary profile
          try {
            const cachedProfileRaw = localStorage.getItem("masjid_user_profile");
            if (cachedProfileRaw) {
              const cachedProfile: UserProfile = JSON.parse(cachedProfileRaw);
              if (cachedProfile && cachedProfile.uid === fbUser.uid) {
                setCurrentUser(cachedProfile);
                if (cachedProfile.activeMasjidId) {
                  setActiveMasjidId(cachedProfile.activeMasjidId);
                }
                return;
              }
            }
          } catch (jsonErr) {
            console.error("Cached profile restoration error:", jsonErr);
          }

          const fallbackProfile: UserProfile = {
            uid: fbUser.uid,
            name: fbUser.displayName || "அறியப்படாத பயனர் (Offline)",
            email: fbUser.email || "",
            phone: fbUser.phoneNumber || "",
            activeMasjidId: localStorage.getItem("masjid_active_id") || "",
            createdAt: new Date().toISOString(),
          };
          setCurrentUser(fallbackProfile);
          if (fallbackProfile.activeMasjidId) {
            setActiveMasjidId(fallbackProfile.activeMasjidId);
          }
        }
      } else {
        // Logged out
        setSyncStatus("local");
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 2. Real-Time Data Fetching (Masjids, Entries & Temp Categories) of Selected Masjid
  useEffect(() => {
    if (!currentUser) return;

    // Local Persistence backup updates
    localStorage.setItem("masjid_user_profile", JSON.stringify(currentUser));
    if (activeMasjidId) {
      localStorage.setItem("masjid_active_id", activeMasjidId);
    } else {
      localStorage.removeItem("masjid_active_id");
    }

    if (!isFirebaseConfigured || !db) {
      setSyncStatus("local");
      return;
    }

    setLoading(true);
    let unsubMasjids = () => {};
    let unsubEntries = () => {};
    let unsubCategories = () => {};

    try {
      // A. Stream all Masjids
      unsubMasjids = onSnapshot(
        collection(db, "masjids"),
        (snapshot: any) => {
          const list: Masjid[] = [];
          snapshot.forEach((docSnap: any) => {
            const data = docSnap.data();
            list.push({
              id: docSnap.id,
              name: data.name,
              area: data.area,
              createdBy: data.createdBy,
              createdAt: data.createdAt,
              clearPassword: data.clearPassword || "",
            });
          });
          setMasjids(list);
          localStorage.setItem("masjid_list", JSON.stringify(list));
        },
        (err: any) => {
          handleFirestoreError(err, OperationType.LIST, "masjids");
        }
      );

      // B. Stream Entries and C. Temp Categories ONLY if activeMasjidId matches
      if (activeMasjidId) {
        const entriesQuery = query(
          collection(db, "entries"),
          where("masjidId", "==", activeMasjidId)
        );

        unsubEntries = onSnapshot(
          entriesQuery,
          (snapshot: any) => {
            const list: FinanceEntry[] = [];
            snapshot.forEach((docSnap: any) => {
              const data = docSnap.data();
              list.push({
                id: docSnap.id,
                type: data.type,
                date: data.date,
                category: data.category,
                amount: data.amount,
                description: data.description,
                createdAt: data.createdAt,
                month: data.month,
                year: data.year,
                quarter: data.quarter,
                masjidId: data.masjidId,
                userId: data.userId,
              });
            });
            // Sort by date descending
            list.sort((a, b) => b.date.localeCompare(a.date));
            setEntries(list);
            localStorage.setItem("masjid_entries", JSON.stringify(list));
          },
          (err: any) => {
            handleFirestoreError(err, OperationType.LIST, `entries_masjid_${activeMasjidId}`);
          }
        );

        const catsQuery = query(
          collection(db, "temp_categories"),
          where("masjidId", "==", activeMasjidId)
        );

        unsubCategories = onSnapshot(
          catsQuery,
          (snapshot: any) => {
            const list: TempCategory[] = [];
            snapshot.forEach((docSnap: any) => {
              const data = docSnap.data();
              list.push({
                id: docSnap.id,
                name: data.name,
                type: data.type,
                month: data.month,
                createdAt: data.createdAt,
                masjidId: data.masjidId,
              });
            });
            setTempCategories(list);
            localStorage.setItem("masjid_temp_cats", JSON.stringify(list));
          },
          (err: any) => {
            handleFirestoreError(err, OperationType.LIST, `temp_categories_masjid_${activeMasjidId}`);
          }
        );
      }

      setSyncStatus("live");
    } catch (error) {
      console.error("Firestore streams failed:", error);
      setSyncStatus("local");
    } finally {
      setLoading(false);
    }

    return () => {
      unsubMasjids();
      unsubEntries();
      unsubCategories();
    };
  }, [currentUser, activeMasjidId]);

  // Handle Logout
  const handleLogout = async () => {
    setLoading(true);
    if (isFirebaseConfigured && auth) {
      await signOut(auth);
    }
    setCurrentUser(null);
    setActiveMasjidId(null);
    setEntries([]);
    setTempCategories([]);
    localStorage.removeItem("masjid_user_profile");
    localStorage.removeItem("masjid_active_id");
    localStorage.removeItem("masjid_entries");
    localStorage.removeItem("masjid_temp_cats");
    setLoading(false);
  };

  // Select active Masjid
  const handleSelectMasjid = async (id: string) => {
    setActiveMasjidId(id);
    localStorage.setItem("masjid_active_id", id);

    // Save choice in profile
    if (currentUser) {
      const updated = { ...currentUser, activeMasjidId: id };
      setCurrentUser(updated);
      localStorage.setItem("masjid_user_profile", JSON.stringify(updated));

      if (isFirebaseConfigured && db) {
        try {
          await updateDoc(doc(db, "users", currentUser.uid), {
            activeMasjidId: id,
          });
        } catch (err) {
          console.error("Failed to update active masjid ID in firestore:", err);
        }
      }
    }
  };

  // Add new Masjid profile
  const handleCreateMasjid = async (name: string, area: string) => {
    if (!currentUser) return;
    setLoading(true);

    const newMasjidPayload: Omit<Masjid, "id"> = {
      name,
      area,
      createdBy: currentUser.uid,
      createdAt: new Date().toISOString(),
    };

    if (isFirebaseConfigured && db) {
      try {
        const docRef = await addDoc(collection(db, "masjids"), {
          ...newMasjidPayload,
          createdAt: serverTimestamp(),
        });
        await handleSelectMasjid(docRef.id);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, "masjids");
      } finally {
        setLoading(false);
      }
    } else {
      // Local setup simulation
      const newId = `masjid-local-${Date.now()}`;
      const newMasjid: Masjid = {
        id: newId,
        ...newMasjidPayload,
      };
      const updatedList = [...masjids, newMasjid];
      setMasjids(updatedList);
      localStorage.setItem("masjid_list", JSON.stringify(updatedList));
      await handleSelectMasjid(newId);
      setLoading(false);
    }
  };

  // Add new temporary category
  const handleAddTempCategory = async (name: string, type: "income" | "expense", month: string): Promise<string> => {
    if (!activeMasjidId) throw new Error("No active masjid selected");

    const categoryPayload: Omit<TempCategory, "id"> = {
      name,
      type,
      month,
      createdAt: new Date().toISOString(),
      masjidId: activeMasjidId,
    };

    if (isFirebaseConfigured && db) {
      try {
        const docRef = await addDoc(collection(db, "temp_categories"), {
          ...categoryPayload,
          createdAt: serverTimestamp(),
        });
        return docRef.id;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, "temp_categories");
        throw err;
      }
    } else {
      const newId = `cat-local-${Date.now()}`;
      const newCat: TempCategory = {
        id: newId,
        ...categoryPayload,
      };
      const updatedList = [...tempCategories, newCat];
      setTempCategories(updatedList);
      localStorage.setItem("masjid_temp_cats", JSON.stringify(updatedList));
      return newId;
    }
  };

  // Update security/clear password for Masjid (Tamil + English layout supported)
  const handleUpdateMasjidPassword = async (masjidId: string, passcode: string) => {
    setLoading(true);
    if (isFirebaseConfigured && db) {
      try {
        await updateDoc(doc(db, "masjids", masjidId), {
          clearPassword: passcode,
        });
      } catch (err) {
        console.error("Failed to update password in firestore:", err);
      }
    } else {
      const updatedList = masjids.map((m) =>
        m.id === masjidId ? { ...m, clearPassword: passcode } : m
      );
      setMasjids(updatedList);
      localStorage.setItem("masjid_list", JSON.stringify(updatedList));
    }
    setLoading(false);
  };

  // Perform All Clear of all active Masjid accounts
  const handleClearMasjidData = async (masjidId: string) => {
    setLoading(true);
    if (isFirebaseConfigured && db) {
      try {
        // Query of related entries in Firestore
        const entriesSnap = await getDocs(
          query(collection(db, "entries"), where("masjidId", "==", masjidId))
        );
        for (const docSnap of entriesSnap.docs) {
          await deleteDoc(doc(db, "entries", docSnap.id));
        }

        // Query of temporary categories in Firestore
        const catsSnap = await getDocs(
          query(collection(db, "temp_categories"), where("masjidId", "==", masjidId))
        );
        for (const docSnap of catsSnap.docs) {
          await deleteDoc(doc(db, "temp_categories", docSnap.id));
        }
      } catch (err) {
        console.error("Firestore cleanup failed:", err);
      }
    }

    // Offline / fallback storage update
    const remainingEntries = entries.filter((e) => e.masjidId !== masjidId);
    setEntries(remainingEntries);
    localStorage.setItem("masjid_entries", JSON.stringify(remainingEntries));

    const remainingCats = tempCategories.filter((c) => c.masjidId !== masjidId);
    setTempCategories(remainingCats);
    localStorage.setItem("masjid_temp_cats", JSON.stringify(remainingCats));

    setLoading(false);
  };

  // Add new Financial Entry to Selected Masjid
  const handleSaveEntry = async (entry: {
    type: "income" | "expense";
    date: string;
    category: string;
    amount: number;
    description: string;
  }) => {
    if (!currentUser || !activeMasjidId) {
      throw new Error("Missing active user or masjid.");
    }

    // Determine calendar quarters
    const [y, m, d] = entry.date.split("-");
    const monthNum = parseInt(m, 10);
    let qStr = "Q1";
    if (monthNum >= 4 && monthNum <= 6) qStr = "Q2";
    else if (monthNum >= 7 && monthNum <= 9) qStr = "Q3";
    else if (monthNum >= 10 && monthNum <= 12) qStr = "Q4";

    const quarterFormat = `${qStr}-${y}`;
    const monthFormat = `${y}-${m}`;

    const newEntryPayload: Omit<FinanceEntry, "id" | "createdAt"> = {
      type: entry.type,
      date: entry.date,
      category: entry.category,
      amount: entry.amount,
      description: entry.description,
      month: monthFormat,
      year: y,
      quarter: quarterFormat,
      masjidId: activeMasjidId,
      userId: currentUser.uid,
    };

    if (isFirebaseConfigured && db) {
      try {
        await addDoc(collection(db, "entries"), {
          ...newEntryPayload,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, "entries");
        throw err;
      }
    } else {
      // Local simulation
      const newEntry: FinanceEntry = {
        id: `entry-local-${Date.now()}`,
        createdAt: new Date().toISOString(),
        ...newEntryPayload,
      };
      const updatedList = [newEntry, ...entries];
      setEntries(updatedList);
      localStorage.setItem("masjid_entries", JSON.stringify(updatedList));
    }
  };

  // Find currently active masjid object details
  const activeMasjidObj = masjids.find((m) => m.id === activeMasjidId);

  // Authentication gate
  if (!currentUser) {
    if (loading) return <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center transition-colors"><Loader message="சுயவிவரம் சரிபார்க்கப்படுகிறது..." /></div>;
    return <LoginPage onLogin={setCurrentUser} isFirebaseConfigured={isFirebaseConfigured} />;
  }

  // Active Mosque registration gate
  if (!activeMasjidId || !activeMasjidObj) {
    if (loading) return <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center transition-colors"><Loader message="தகவல்கள் சேகரிக்கப்படுகிறது..." /></div>;
    return (
      <MasjidSetup
        masjids={masjids}
        onSelectMasjid={handleSelectMasjid}
        onCreateMasjid={handleCreateMasjid}
        onLogout={handleLogout}
        currentUser={currentUser}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-between font-sans pb-24 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Top Banner Navigation Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 shadow-xs sticky top-0 z-40 print:hidden transition-colors duration-200">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-xl transition-colors">
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold text-slate-900 dark:text-slate-100 leading-tight transition-colors">
                {activeMasjidObj.name}
              </h1>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold">{activeMasjidObj.area}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Sync Indicator */}
            {syncStatus === "live" ? (
              <span className="hidden sm:inline-flex items-center text-[10px] text-emerald-800 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-full font-bold transition-colors">
                <RefreshCw className="h-2.5 w-2.5 mr-1 animate-spin text-emerald-600 dark:text-emerald-400" /> ஃபயர்பேஸ் லைவ்
              </span>
            ) : (
              <span className="hidden sm:inline-flex items-center text-[10px] text-amber-800 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/50 px-2 py-0.5 rounded-full font-bold transition-colors">
                <RefreshCwOff className="h-2.5 w-2.5 mr-1 text-amber-600 dark:text-amber-400" /> ஆஃப்லைன் சேமிப்பு
              </span>
            )}

            {/* Install App Button */}
            <button
              onClick={() => setIsInstallModalOpen(true)}
              title="அலைபேசி செயலி & GitHub (Download App / PWA)"
              className="px-2.5 py-1.5 text-emerald-700 hover:text-emerald-800 dark:text-emerald-300 dark:hover:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/50 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-all font-bold text-xs flex items-center space-x-1 cursor-pointer"
            >
              <Smartphone className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>பதிவிறக்கம் (App)</span>
            </button>

            {/* Dark/Light mode toggle */}
            <button
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              title={theme === "light" ? "இருண்ட பயன்முறை" : "ஒளி பயன்முறை"}
              className="p-1.5 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
            </button>

            {/* Settings & Security Button */}
            <button
              onClick={() => {
                setSettingsErr("");
                setSettingsSuccess("");
                setCurrentPasswordInput("");
                setNewPasswordInput("");
                setConfirmNewPasswordInput("");
                setForgotEmailInput("");
                setRetrievedPassword("");
                setIsForgotPwOpen(false);
                setIsClearConfirmOpen(false);
                setClearConfirmPasswordInput("");
                setIsSettingsModalOpen(true);
              }}
              title="பாதுகாப்பு & அமைப்புகள் (Settings & Security)"
              className="p-1.5 text-slate-500 hover:text-emerald-600 dark:text-slate-400 dark:hover:text-emerald-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer"
            >
              <Settings className="h-4 w-4" />
            </button>

            {/* Change Mosque Button */}
            <button
              onClick={() => {
                setActiveMasjidId(null);
                localStorage.removeItem("masjid_active_id");
              }}
              className="text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-emerald-75 dark:hover:text-emerald-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer"
            >
              மாற்று
            </button>

            {/* Logout icon */}
            <button
              onClick={handleLogout}
              title="வெளியேறு (Logout)"
              className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors cursor-pointer"
            >
              <LogOut className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Tab Screen Wrapper */}
      <main className="flex-grow py-4 px-2">
        {loading && (
          <div className="fixed inset-0 bg-white/70 dark:bg-slate-950/70 backdrop-blur-xs flex items-center justify-center z-50">
            <Loader message="ஏற்றப்படுகிறது..." />
          </div>
        )}

        <div className="max-w-4xl mx-auto">
          {activeTab === "entry" && (
            <EntryTab
              activeMasjidId={activeMasjidId}
              tempCategories={tempCategories}
              onAddTempCategory={handleAddTempCategory}
              onSaveEntry={handleSaveEntry}
            />
          )}

          {activeTab === "statement" && (
            <StatementTab
              entries={entries}
              activeMasjidId={activeMasjidId}
              onSwitchTab={setActiveTab}
              masjidName={activeMasjidObj.name}
              masjidArea={activeMasjidObj.area}
            />
          )}

          {activeTab === "category" && (
            <CategoryTab
              entries={entries}
              tempCategories={tempCategories}
              activeMasjidId={activeMasjidId}
              masjidName={activeMasjidObj.name}
              masjidArea={activeMasjidObj.area}
            />
          )}
        </div>
      </main>

       {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 py-1.5 shadow-xl px-4 z-40 print:hidden transition-colors duration-200">
        <div className="max-w-md mx-auto flex justify-around">
          {/* TAB 1: பதிவு */}
          <button
            onClick={() => setActiveTab("entry")}
            className={`flex flex-col items-center flex-1 py-1.5 cursor-pointer transition-colors ${
              activeTab === "entry" ? "text-[#1D9E75]" : "text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300"
            }`}
          >
            <PlusCircle className="h-6 w-6" />
            <span className="text-[10px] font-bold mt-1">பதிவு (Entry)</span>
          </button>

          {/* TAB 2: அறிக்கை */}
          <button
            onClick={() => setActiveTab("statement")}
            className={`flex flex-col items-center flex-1 py-1.5 cursor-pointer transition-colors ${
              activeTab === "statement" ? "text-[#1D9E75]" : "text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300"
            }`}
          >
            <BarChart className="h-6 w-6" />
            <span className="text-[10px] font-bold mt-1">அறிக்கை (Statement)</span>
          </button>

          {/* TAB 3: வகை */}
          <button
            onClick={() => setActiveTab("category")}
            className={`flex flex-col items-center flex-1 py-1.5 cursor-pointer transition-colors ${
              activeTab === "category" ? "text-[#1D9E75]" : "text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300"
            }`}
          >
            <Tag className="h-6 w-6" />
            <span className="text-[10px] font-bold mt-1">வகை (Category Cost)</span>
          </button>
        </div>
      </nav>

      {/* App Install & GitHub Pages deployment Tutorial Dialog Modal */}
      {isInstallModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden text-left transform transition-all">
            {/* Modal Header */}
            <div className="flex px-6 py-4 items-center justify-between border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-lg">
                  <Smartphone className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-50 leading-tight">அலைபேசி செயலி & GitHub</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Download App & GitHub Guides</p>
                </div>
              </div>
              <button
                onClick={() => setIsInstallModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-850 rounded-lg cursor-pointer transition-colors"
                title="மூடு"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Navigation Tabs */}
            <div className="flex border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
              <button
                onClick={() => setInstallTab("apk")}
                className={`flex-1 py-3 px-4 text-center font-bold text-sm border-b-2 flex items-center justify-center space-x-2 cursor-pointer transition-colors ${
                  installTab === "apk"
                    ? "border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-850"
                    : "border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400"
                }`}
              >
                <Smartphone className="h-4 w-4" />
                <span>அலைபேசி செயலி (Mobile App)</span>
              </button>
              <button
                onClick={() => setInstallTab("github")}
                className={`flex-1 py-3 px-4 text-center font-bold text-sm border-b-2 flex items-center justify-center space-x-2 cursor-pointer transition-colors ${
                  installTab === "github"
                    ? "border-emerald-500 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-slate-850"
                    : "border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400"
                }`}
              >
                <Github className="h-4 w-4" />
                <span>GitHub Pages (இணையத்தளம்)</span>
              </button>
            </div>

            {/* Modal Dynamic Content */}
            <div className="p-6">
              {installTab === "apk" ? (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                    <p className="text-xs text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                      💡 அலைபேசிக்கான அதிநவீன செயலி வழிமுறை (PWA):
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 leading-relaxed font-medium">
                      உங்கள் அலைபேசிக்கு தனி APK கோப்பு தேவையில்லை! இந்த செயலி <strong>PWA (Progressive Web App)</strong> ஆக வடிவமைக்கப்பட்டுள்ளது.
                      இதை உங்கள் போனில் நிறுவினால், அது <strong>offline</strong> ஆக இயங்கும், அழகான மொபைல் ஐகானுடன் முழு திரையில் தோன்றும்!
                    </p>
                  </div>

                  <div className="space-y-3.5">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        1
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Android (Chrome உலாவி):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium">
                          Chrome-ல் இந்த முகவரியைத் திறந்து, மேலே வலதுபுறத்தில் உள்ள <strong>மூன்று புள்ளிகளை (⋮)</strong> கிளிக் செய்து, 
                          <strong>"Install App"</strong> அல்லது <strong>"Add to Home Screen"</strong> என்பதைத் தேர்ந்தெடுக்கவும்.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        2
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">iOS/iPhone (Safari உலாவி):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium">
                          Safari-ல் இந்த முகவரியைத் திறந்து, கீழே உள்ள <strong>பகிர்வு (Share - 📤)</strong> ஐகானை அழுத்தி, 
                          <strong>"Add to Home Screen"</strong> என்பதைத் தேர்ந்தெடுக்கவும்.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        3
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">நேரடி நிறுவல் (Instant Installer):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium mb-3">
                          உங்கள் போன்/உலாவி ஆதரித்தால் கீழே உள்ள பொத்தானை அழுத்தி உடனடியாக நிறுவலாம்:
                        </p>
                        {showInstallPwaBtn ? (
                          <button
                            onClick={handleInstallPWA}
                            className="inline-flex items-center space-x-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-md cursor-pointer transition-all"
                          >
                            <Smartphone className="h-4 w-4" />
                            <span>செயலியை நிறுவு (Install App Now)</span>
                          </button>
                        ) : (
                          <span className="text-xs bg-slate-50 dark:bg-slate-850 px-3 py-1.5 rounded-md border border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 font-bold block w-fit">
                            ✓ செயலி நிறுவ தயாராக உள்ளது (அல்லது ஏற்கனவே நிறுவப்பட்டுள்ளது)
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/25 rounded-xl border border-emerald-100 dark:border-emerald-900/30">
                    <p className="text-xs text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                      🔗 GitHub Pages முகவரி (Domain): 
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-400 leading-relaxed font-mono font-bold">
                      https://&lt;your-username&gt;.github.io/
                    </p>
                  </div>

                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    இந்தச் செயலியை உங்கள் சொந்த இலவச இணையதள முகவரியில் (GitHub Pages) நிரந்தரமாகப் பதிவேற்றி அனைவரும் பயன்படுத்த வைக்க பின்வரும் வழிகளைப் பின்பற்றவும்:
                  </p>

                  <div className="space-y-3.5">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        1
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">கோப்புகளை ஏற்றுமதி செய்க (Export):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium">
                          AI Studio மெனுவில் உள்ள <strong>"Export to GitHub"</strong> அல்லது <strong>"Export ZIP"</strong> என்பதைத் தேர்வு செய்து கோப்புகளை உங்கள் GitHub கணக்கிற்கு கொண்டு செல்லவும்.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        2
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">தானியங்கி கட்டமைப்பு (Auto Deploy):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium">
                          நாங்கள் உருவாக்கியுள்ள <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded text-rose-500 text-[11px] font-mono">deploy.yml</code> தானியங்கி கோப்பு (GitHub Action Workflow), நீங்கள் குறியீட்டைப் பதிவேற்றியவுடன் தானாகவே கட்டமைத்து <strong>gh-pages</strong> கிளையில் வெளியிடும்!
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center font-bold text-xs mt-0.5">
                        3
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">இணையதள முகவரியை இயக்குக (Pages Settings):</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-0.5 font-medium">
                          உங்கள் GitHub பக்கத்தில் <strong>Settings → Pages</strong> சென்று, Source பகுதியை <strong>"Deploy from a branch"</strong> எனத் தேர்ந்தெடுத்து, கிளையாக (Branch) <strong>"gh-pages"</strong> என்பதைத் தேர்வு செய்து சேமிக்கவும்.சில நிமிடங்களில் இணையப்பக்கம் நேரலையாகிவிடும்!
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 text-right">
              <button
                onClick={() => setIsInstallModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                சரி, புரிந்தது!
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Settings, Password Setup & Data Reset Dialog Modal */}
      {isSettingsModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-100 dark:border-slate-800 overflow-hidden text-left transform transition-all">
            {/* Modal Header */}
            <div className="flex px-6 py-4 items-center justify-between border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400 rounded-lg">
                  <Settings className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-50 leading-tight">மஸ்ஜித் பாதுகாப்பு & அமைப்புகள்</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">Security & Data Control - {activeMasjidObj.name}</p>
                </div>
              </div>
              <button
                onClick={() => setIsSettingsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-850 rounded-lg cursor-pointer transition-colors"
                title="மூடு"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 space-y-6">
              {/* Notifications */}
              {settingsErr && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-xs rounded-xl flex items-start space-x-2.5">
                  <X className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{settingsErr}</span>
                </div>
              )}
              {settingsSuccess && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs rounded-xl flex items-start space-x-2.5">
                  <Check className="h-4 w-4 shrink-0 mt-0.5" />
                  <span>{settingsSuccess}</span>
                </div>
              )}

              {/* Informational Guidance regarding billing and cloud persistence */}
              <div className="p-4 bg-emerald-50/60 dark:bg-emerald-950/15 rounded-xl border border-emerald-100/60 dark:border-emerald-900/20">
                <div className="flex items-start space-x-2.5">
                  <Info className="h-4 w-4 text-[#1D9E75] shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-[#1D9E75]">மெய்நிகர் மேகக்கணி தரவு பாதுகாப்பு (Permanent Safe Sync)</h4>
                    <p className="text-[11px] text-slate-600 dark:text-slate-450 mt-1 leading-relaxed">
                      <strong>இலவச கூகிள் பயர்பேஸ் (Free Spark Plan)</strong> மூலம் இந்தத் தரவு சேமிக்கப்படுகிறது. இதற்கு எந்தக் கட்டணமும் (No Billing Setup) தேவையில்லை. 
                      நீங்கள் கணக்கிலிருந்து வெளியேறினாலும் (Logout), மீண்டும் அதே <strong>மின்னஞ்சல் முகவரி</strong> மூலம் உள்நுழையும் போது உங்கள் பள்ளிவாசலின் அனைத்து வரவு செலவு கணக்குகளும் 100% பாதுகாப்பாக மீட்டெடுக்கப்படும்!
                    </p>
                  </div>
                </div>
              </div>

              {/* SECTION 1: Password Lock / Setup */}
              <div className="border border-slate-100 dark:border-slate-800/80 rounded-xl p-4 bg-slate-50/30 dark:bg-slate-900/20 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Lock className="h-4.5 w-4.5 text-emerald-600 dark:text-emerald-450" />
                    <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">மஸ்ஜித் பாதுகாப்பு கடவுச்சொல் (Security Password)</span>
                  </div>
                  {activeMasjidObj.clearPassword ? (
                    <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/20 px-2.5 py-0.5 rounded-full font-bold">
                      🔒 கடவுச்சொல் இயக்கத்தில் உள்ளது
                    </span>
                  ) : (
                    <span className="text-[10px] bg-amber-50 dark:bg-amber-955/65 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-900/25 px-2.5 py-0.5 rounded-full font-bold">
                      ⚠️ கடவுச்சொல் அமைக்கப்படவில்லை
                    </span>
                  )}
                </div>

                {!isForgotPwOpen ? (
                  <div className="space-y-3.5">
                    {activeMasjidObj.clearPassword && (
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400">தற்போதைய கடவுச்சொல் (Current Security Password)</label>
                        <input
                          type={showPasswordText ? "text" : "password"}
                          value={currentPasswordInput}
                          onChange={(e) => setCurrentPasswordInput(e.target.value)}
                          placeholder="••••••••"
                          className="mt-1 block w-full px-3 py-2 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-lg text-xs"
                        />
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400">புதிய பாதுகாப்பு கடவுச்சொல் (New Password)</label>
                        <input
                          type={showPasswordText ? "text" : "password"}
                          value={newPasswordInput}
                          onChange={(e) => setNewPasswordInput(e.target.value)}
                          placeholder="குறைந்தது 4 எழுத்துக்கள்"
                          className="mt-1 block w-full px-3 py-2 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-lg text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 dark:text-slate-400">கடவுச்சொல் உறுதிப்படுத்தல்</label>
                        <input
                          type={showPasswordText ? "text" : "password"}
                          value={confirmNewPasswordInput}
                          onChange={(e) => setConfirmNewPasswordInput(e.target.value)}
                          placeholder="மீண்டும் கடவுச்சொல்"
                          className="mt-1 block w-full px-3 py-2 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-lg text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <button
                        type="button"
                        onClick={() => setShowPasswordText(!showPasswordText)}
                        className="text-[10px] text-slate-500 dark:text-slate-400 hover:text-slate-700 flex items-center space-x-1 cursor-pointer"
                      >
                        {showPasswordText ? <EyeOff className="h-3.5 w-3.5 text-slate-400" /> : <Eye className="h-3.5 w-3.5 text-slate-400" />}
                        <span>கடவுச்சொல்லை {showPasswordText ? "மறை" : "காண்பி"}</span>
                      </button>

                      {activeMasjidObj.clearPassword && (
                        <button
                          type="button"
                          onClick={() => {
                            setSettingsErr("");
                            setSettingsSuccess("");
                            setIsForgotPwOpen(true);
                            setForgotEmailInput("");
                            setRetrievedPassword("");
                          }}
                          className="text-[10px] text-emerald-600 dark:text-emerald-450 hover:underline cursor-pointer font-bold"
                        >
                          கடவுச்சொல் மறந்துவிட்டதா? (Forgot Password)
                        </button>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={async () => {
                        setSettingsErr("");
                        setSettingsSuccess("");
                        if (!newPasswordInput) {
                          setSettingsErr("கடவுச்சொல் புலங்களை நிரப்பவும்.");
                          return;
                        }
                        if (newPasswordInput.length < 4) {
                          setSettingsErr("பாதுகாப்பு கடவுச்சொல் குறைந்தது 4 எழுத்துக்கள் இருக்க வேண்டும்.");
                          return;
                        }
                        if (newPasswordInput !== confirmNewPasswordInput) {
                          setSettingsErr("இரு புதிய கடவுச்சொற்களும் சரியாக பொருந்தவில்லை!");
                          return;
                        }

                        // If password exists, they must enter verified password or matches
                        if (activeMasjidObj.clearPassword && currentPasswordInput !== activeMasjidObj.clearPassword) {
                          setSettingsErr("தற்போதைய பாதுகாப்பு கடவுச்சொல் தவறானது!");
                          return;
                        }

                        await handleUpdateMasjidPassword(activeMasjidId, newPasswordInput);
                        setSettingsSuccess("பாதுகாப்பு கடவுச்சொல் வெற்றிகரமாக மேம்படுத்தப்பட்டது!");
                        setCurrentPasswordInput("");
                        setNewPasswordInput("");
                        setConfirmNewPasswordInput("");
                      }}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-colors"
                    >
                      {activeMasjidObj.clearPassword ? "கடவுச்சொல்லை மாற்று (Update Password)" : "புதிய கடவுச்சொல்லை அமை (Set Password)"}
                    </button>
                  </div>
                ) : (
                  /* Forgot Password Form */
                  <div className="p-3 bg-slate-55 dark:bg-slate-850 rounded-lg space-y-3.5">
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200">மின்னஞ்சல் மூலம் கடவுச்சொல் மீட்பு (Retrieve Password)</span>
                    </div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
                      தற்போது லாகின் செய்துள்ள உங்கள் கணக்கின் மின்னஞ்சல் முகவரியை <strong>({currentUser.email})</strong> அப்படியே தட்டச்சு செய்யவும்:
                    </p>
                    <input
                      type="email"
                      value={forgotEmailInput}
                      onChange={(e) => setForgotEmailInput(e.target.value)}
                      placeholder="உதாரணம்: dynamic@example.com"
                      className="block w-full px-3 py-2 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-lg text-xs"
                    />

                    {retrievedPassword && (
                      <div className="p-2.5 bg-emerald-100/70 dark:bg-emerald-950/40 border border-emerald-250 dark:border-emerald-900 rounded-lg text-xs">
                        <p className="font-extrabold text-emerald-800 dark:text-emerald-400">உறுதிப்படுத்தப்பட்டது! தற்போதைய கடவுச்சொல் (Stored Password):</p>
                        <p className="mt-1 font-mono font-bold text-slate-800 dark:text-slate-100 px-2 py-1 bg-white dark:bg-slate-900 border border-slate-105 rounded text-center text-sm tracking-wider">
                          {retrievedPassword}
                        </p>
                      </div>
                    )}

                    <div className="flex space-x-2">
                      <button
                        type="button"
                        onClick={() => {
                          setIsForgotPwOpen(false);
                          setSettingsErr("");
                          setSettingsSuccess("");
                        }}
                        className="flex-1 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-850 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-bold cursor-pointer"
                      >
                        பின்செல்லவும் (Cancel)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSettingsErr("");
                          if (!forgotEmailInput) {
                            setSettingsErr("மின்னஞ்சல் முகவரியை தட்டச்சு செய்யவும்.");
                            return;
                          }
                          const normalizedInput = forgotEmailInput.trim().toLowerCase();
                          const normalizedUserEmail = currentUser.email.trim().toLowerCase();
                          if (normalizedInput !== normalizedUserEmail) {
                            setSettingsErr("லாகின் செய்துள்ள மின்னஞ்சல் கோரிக்கை தவறானது! தயவுசெய்து உங்கள் கணக்கு மின்னஞ்சலை உள்ளிடவும்.");
                            return;
                          }

                          // Success match
                          if (activeMasjidObj.clearPassword) {
                            setRetrievedPassword(activeMasjidObj.clearPassword);
                            setSettingsSuccess("உரிமையாளர் சரிபார்ப்பு வெற்றிகரமாக முடிந்தது!");
                          } else {
                            setSettingsErr("இந்த பள்ளிவாசலுக்கு கடவுச்சொல் எதுவும் அமைக்கப்படவில்லை!");
                          }
                        }}
                        className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold cursor-pointer"
                      >
                        சரிபார் (Verify Email)
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* SECTION 2: All Clear (Reset database) */}
              <div className="border border-red-100 dark:border-red-950/40 rounded-xl p-4 bg-red-50/10 dark:bg-red-955/5 space-y-3">
                <div className="flex items-center space-x-2 text-rose-600 dark:text-rose-450">
                  <Trash2 className="h-5 w-5" />
                  <span className="text-xs font-extrabold">பள்ளிவாசல் கணக்குகள் முழுமையாக நீக்கம் (All Clear / Reset Data)</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
                  இந்த பள்ளிவாசலின் <strong>வருமானப் பதிவுகள், செலவுக் கணக்குகள் மற்றும் தனிப்பயன் வகைகள் அனைத்தும்</strong> நிரந்தரமாக அழிக்கப்படும். அழித்த விவரங்களை மீட்டெடுக்க முடியாது!
                </p>

                {!isClearConfirmOpen ? (
                  <button
                    type="button"
                    onClick={() => {
                      setSettingsErr("");
                      setSettingsSuccess("");
                      setClearConfirmPasswordInput("");
                      setIsClearConfirmOpen(true);
                      
                      // Notify the user if no password is set to safety guide
                      if (!activeMasjidObj.clearPassword) {
                        setSettingsErr("⚠️ இந்த பள்ளிவாசலுக்கு இன்னும் கடவுச்சொல் அமைக்கப்படவில்லை. தயவுசெய்து மேலே கடவுச்சொல் ஒன்றை அமைத்துக் கொள்ளும்படி கேட்டுக்கொள்கிறோம்.");
                      }
                    }}
                    className="px-3 py-1.5 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:hover:bg-red-900/40 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-9D0 rounded-lg text-xs font-extrabold cursor-pointer transition-colors"
                  >
                    தரவுகளை அழிக்கத் தொடங்கு (Start All Clear)
                  </button>
                ) : (
                  <div className="p-3 bg-red-50/40 dark:bg-red-950/10 border border-red-200 dark:border-red-900/30 rounded-lg space-y-3">
                    <p className="text-xs font-extrabold text-red-800 dark:text-red-400 leading-snug">⚠️ இறுதி உறுதிப்படுத்தல் தேவை (Final Reset Confirmation):</p>
                    
                    {activeMasjidObj.clearPassword ? (
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 font-bold">கணக்குகளை நிரந்தரமாக நீக்க கடவுச்சொல்லை உள்ளிடவும்:</label>
                        <input
                          type="password"
                          value={clearConfirmPasswordInput}
                          onChange={(e) => setClearConfirmPasswordInput(e.target.value)}
                          placeholder="பாதுகாப்பு கடவுச்சொல்"
                          className="mt-1 block w-full px-2.5 py-1.5 border border-red-300 dark:border-red-900 bg-white dark:bg-slate-800 rounded-lg text-xs font-mono"
                        />
                      </div>
                    ) : (
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 font-bold">கடவுச்சொல் இல்லை. பின்வரும் சொல்லை அப்படியே தட்டச்சு செய்யவும்: <code className="bg-red-100 dark:bg-red-950 px-1 py-0.5 rounded font-mono text-rose-500 font-bold text-[11px]">DELETE</code></label>
                        <input
                          type="text"
                          value={clearConfirmPasswordInput}
                          onChange={(e) => setClearConfirmPasswordInput(e.target.value)}
                          placeholder="DELETE"
                          className="mt-1 block w-full px-2.5 py-1.5 border border-red-300 dark:border-red-900 bg-white dark:bg-slate-800 rounded-lg text-xs font-bold text-center"
                        />
                      </div>
                    )}

                    <div className="flex space-x-2 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setIsClearConfirmOpen(false);
                          setSettingsErr("");
                          setSettingsSuccess("");
                        }}
                        className="flex-1 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                      >
                        வேண்டாம், நிறுத்து (Cancel)
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          setSettingsErr("");
                          setSettingsSuccess("");
                          
                          if (!clearConfirmPasswordInput) {
                            setSettingsErr("தேவையான புலத்தை நிரப்பவும்.");
                            return;
                          }

                          if (activeMasjidObj.clearPassword) {
                            if (clearConfirmPasswordInput !== activeMasjidObj.clearPassword) {
                              setSettingsErr("அழிக்க நீங்கள் உள்ளிட்ட பாதுகாப்பு கடவுச்சொல் தவறானது!");
                              return;
                            }
                          } else {
                            if (clearConfirmPasswordInput.toUpperCase() !== "DELETE") {
                              setSettingsErr("உறுதிப்படுத்தல் சொல்லை 'DELETE' எனச் தட்டச்சு செய்யவும்!");
                              return;
                            }
                          }

                          // Proceed deletion
                          await handleClearMasjidData(activeMasjidId);
                          setSettingsSuccess("இந்த பள்ளிவாசலின் அனைத்து கணக்கு விவரங்களும் வெற்றிகரமாக அழிக்கப்பட்டன!");
                          setIsClearConfirmOpen(false);
                          setClearConfirmPasswordInput("");
                        }}
                        className="flex-1 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-sm"
                      >
                        உறுதியாக அழி (Confirm Delete)
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-slate-50 dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 text-right">
              <button
                onClick={() => setIsSettingsModalOpen(false)}
                className="px-4 py-2 bg-[#1D9E75] hover:bg-[#158060] text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm"
              >
                முடிந்தது (Close Settings)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

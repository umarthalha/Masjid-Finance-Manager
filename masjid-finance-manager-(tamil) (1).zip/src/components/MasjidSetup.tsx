import React, { useState } from "react";
import { Masjid } from "../types";
import { Plus, Search, MapPin, Building } from "lucide-react";

interface MasjidSetupProps {
  masjids: Masjid[];
  onSelectMasjid: (masjidId: string) => void;
  onCreateMasjid: (name: string, area: string) => void;
  onLogout: () => void;
  currentUser: { name: string; email: string };
}

export default function MasjidSetup({
  masjids,
  onSelectMasjid,
  onCreateMasjid,
  onLogout,
  currentUser,
}: MasjidSetupProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [name, setName] = useState("");
  const [area, setArea] = useState("");
  const [error, setError] = useState("");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError("பள்ளிவாசல் பெயர் குறைந்தது 2 எழுத்துக்கள் இருக்க வேண்டும்.");
      return;
    }
    if (area.trim().length < 2) {
      setError("அமைந்துள்ள பகுதி குறைந்தது 2 எழுத்துக்கள் இருக்க வேண்டும்.");
      return;
    }
    setError("");
    onCreateMasjid(name.trim(), area.trim());
    setName("");
    setArea("");
    setShowCreateForm(false);
  };

  const filteredMasjids = masjids.filter((masjid) => {
    const term = searchTerm.toLowerCase();
    return (
      masjid.name.toLowerCase().includes(term) ||
      masjid.area.toLowerCase().includes(term)
    );
  });

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-center py-10 px-4 font-sans transition-colors duration-200">
      <div className="max-w-2xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mx-auto h-14 w-14 bg-emerald-600 dark:bg-emerald-700 text-white rounded-2xl flex items-center justify-center shadow-lg transform rotate-2 mb-4">
            <Building className="h-8 w-8" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-slate-100 leading-snug">
            சுங்கப் பள்ளிவாசலைத் தேர்ந்தெடுக்கவும்
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            அன்புடன் வரவேற்கிறோம்,{" "}
            <span className="font-semibold text-emerald-700 dark:text-emerald-450">{currentUser.name}</span>. உங்கள் பள்ளிவாசலை தேர்ந்தெடுக்கவும் அல்லது புதிய பள்ளிவாசலை சேர்க்கவும்.
          </p>
        </div>

        {/* Dashboard */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-800 p-6 overflow-hidden transition-colors">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 dark:bg-rose-950/35 border border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-sm rounded-xl">
              {error}
            </div>
          )}

          {!showCreateForm ? (
            <div className="space-y-6">
              {/* Search and Action Header */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400 dark:text-slate-550" />
                  <input
                    type="text"
                    placeholder="பள்ளிவாசல் பெயர் அல்லது பகுதி கொண்டு தேடுக..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 dark:border-slate-705 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm bg-slate-50 dark:bg-slate-800 focus:bg-white dark:focus:bg-slate-850 text-slate-800 dark:text-slate-100"
                  />
                </div>
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="inline-flex justify-center items-center px-4 py-2.5 border border-transparent rounded-xl text-sm font-medium text-white bg-[#1D9E75] hover:bg-[#158060] shadow-sm transition-colors cursor-pointer"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  புதிய பள்ளிவாசல் சேர்
                </button>
              </div>

              {/* Masjid List Grid */}
              <div>
                <h3 className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">
                  பள்ளிவாசல்கள் பட்டியல் ({filteredMasjids.length})
                </h3>

                {filteredMasjids.length === 0 ? (
                  <div className="text-center py-12 border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-xl bg-slate-25 dark:bg-slate-900/30">
                    <Building className="mx-auto h-10 w-10 text-slate-350 dark:text-slate-600 mb-3" />
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
                      எந்த பள்ளிவாசலும் காணப்படவில்லை.
                    </p>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                      முதலாவதாக உங்கள் பள்ளிவாசலை உருவாக்க முயற்சிக்கவும்!
                    </p>
                    <button
                      onClick={() => setShowCreateForm(true)}
                      className="mt-4 inline-flex items-center text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5 mr-1" /> புதிய பள்ளிவாசலை இப்போது சேர்க்கவும்
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[380px] overflow-y-auto pr-1">
                    {filteredMasjids.map((masjid) => (
                      <div
                        key={masjid.id}
                        onClick={() => onSelectMasjid(masjid.id)}
                        className="group relative flex flex-col justify-between p-4 bg-slate-50 dark:bg-slate-800/40 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 border border-slate-200/60 dark:border-slate-850 hover:border-emerald-300 dark:hover:border-emerald-700/80 rounded-xl cursor-pointer transition-all duration-200 hover:shadow-md"
                      >
                        <div className="flex items-start">
                          <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 group-hover:bg-emerald-500 group-hover:text-white text-emerald-700 dark:text-emerald-400 rounded-xl transition-colors shrink-0">
                            <Building className="h-5 w-5" />
                          </div>
                          <div className="ml-3">
                            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 leading-tight transition-colors">
                              {masjid.name}
                            </h4>
                            <div className="mt-1 flex items-center text-xs text-slate-500 dark:text-slate-450">
                              <MapPin className="h-3 w-3 mr-1 text-slate-400 dark:text-slate-550" />
                              <span>{masjid.area}</span>
                            </div>
                          </div>
                        </div>
                        <div className="mt-4 text-left">
                          <span className="inline-flex text-[10px] bg-slate-200/70 dark:bg-slate-850 text-slate-600 dark:text-slate-300 font-semibold px-2 py-0.5 rounded-full select-none transition-colors">
                            கணக்கு நிர்வகி
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">புதிய பள்ளிவாசல் பதிவு</h3>
                <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">Add New Masjid</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  பள்ளிவாசல் பெயர் (Masjid Name) *
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Building className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="எ.கா. மஸ்ஜித் அந்-நூர் (Masjid An-Noor)"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                  பகுதி / ஊர் (Area / Locality) *
                </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="எ.கா. மண்ணடி, சென்னை (Mannady, Chennai)"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setError("");
                    setShowCreateForm(false);
                  }}
                  className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-350 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
                >
                  பின்செல்லவும் (Back)
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-[#1D9E75] hover:bg-[#158060] rounded-xl shadow-sm transition-colors cursor-pointer"
                >
                  சேமி (Save Mosque)
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer Logout */}
        <div className="mt-6 flex justify-between items-center text-xs">
          <p className="text-slate-500 dark:text-slate-450">சுயவிவர மேலாண்மை அமைப்பு</p>
          <button
            onClick={onLogout}
            className="font-semibold text-rose-600 dark:text-rose-400 hover:text-rose-700 hover:underline cursor-pointer"
          >
            வெளியேறு (Logout)
          </button>
        </div>
      </div>
    </div>
  );
}

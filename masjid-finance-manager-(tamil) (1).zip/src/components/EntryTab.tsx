import React, { useState, useEffect } from "react";
import { TempCategory } from "../types";
import { Plus, Calendar, FileText, CheckCircle, X, HelpCircle } from "lucide-react";

interface EntryTabProps {
  activeMasjidId: string;
  tempCategories: TempCategory[];
  onAddTempCategory: (name: string, type: "income" | "expense", month: string) => Promise<string>;
  onSaveEntry: (entry: {
    type: "income" | "expense";
    date: string;
    category: string;
    amount: number;
    description: string;
  }) => Promise<void>;
}

export default function EntryTab({
  activeMasjidId,
  tempCategories,
  onAddTempCategory,
  onSaveEntry,
}: EntryTabProps) {
  const [type, setType] = useState<"income" | "expense">("income");
  const [date, setDate] = useState(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  });
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState<number | "">("");
  const [description, setDescription] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Popup state for temporary category
  const [showPopup, setShowPopup] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [popupError, setPopupError] = useState("");

  // Calculate current month format (YYYY-MM) from selected date
  const selectedMonth = date.substring(0, 7); // e.g. "2026-05"

  // Base categories
  const baseIncomeCategories = [
    "ஆரம்ப இருப்பு (மாதத்திற்கான)",
    "Rent Shop 1",
    "Rent Shop 2",
    "Rent Shop 3",
    "Rent Shop 4",
    "Rent Shop 5",
    "Rent Shop 6",
    "Rent Shop 7",
    "Rent Shop 8",
    "Rent Shop 9",
    "Rent Shop 10",
    "Rent Shop 11",
    "Rent Shop 12",
    "Rent Shop 13",
    "பாத்திர வாடகை வருமானம்",
    "நிக்காஹ் வசூல்",
    "நன்கொடை வசூல்"
  ];
  const baseExpenseCategories = [
    "ஹஸ்ரத் சம்பளம்",
    "மொதினார் / பிலால் சம்பளம்",
    "மின் கட்டணம்",
    "பஞ்சாயத்து வரி",
    "எழுதுபொருள் வாங்கியது",
    "மின் பொருள் வாங்கியது",
    "வக்ஃப் வரி"
  ];

  // Filter temp categories for active masjid, selected month, and entry type
  const filteredTempCats = tempCategories.filter(
    (cat) =>
      cat.masjidId === activeMasjidId &&
      cat.month === selectedMonth &&
      cat.type === type
  );

  const availableCategories = [
    ...(type === "income" ? baseIncomeCategories : baseExpenseCategories),
    ...filteredTempCats.map((c) => c.name),
  ];

  // Set default category when type or date changes
  useEffect(() => {
    if (availableCategories.length > 0) {
      if (!availableCategories.includes(category)) {
        setCategory(availableCategories[0]);
      }
    } else {
      setCategory("");
    }
  }, [type, selectedMonth]);

  // Handle category selector change
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === "add_new_temp") {
      setShowPopup(true);
    } else {
      setCategory(val);
    }
  };

  const handleAddTempCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const nameTrimmed = newCatName.trim();
    if (!nameTrimmed) {
      setPopupError("வகைப்பெயர் தேவை.");
      return;
    }
    if (availableCategories.includes(nameTrimmed)) {
      setPopupError("வகை ஏற்கனவே உள்ளது.");
      return;
    }

    try {
      setLoading(true);
      await onAddTempCategory(nameTrimmed, type, selectedMonth);
      setCategory(nameTrimmed);
      setNewCatName("");
      setShowPopup(false);
      setPopupError("");
    } catch (err: any) {
      setPopupError("சேமிக்க இயலவில்லை");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!date) {
      setError("தேதி கட்டாயப் புலம்.");
      return;
    }

    // Do not allow future dates
    const selectedDateObj = new Date(date);
    const today = new Date();
    today.setHours(23, 59, 59, 999); // allow today fully
    if (selectedDateObj > today) {
      setError("எதிர்கால தேதிகளை தேர்வு செய்ய முடியாது.");
      return;
    }

    if (!category || category === "add_new_temp") {
      setError("வகை தேர்வு செய்க.");
      return;
    }

    const amtNum = Number(amount);
    if (isNaN(amtNum) || amtNum <= 0) {
      setError("தொகை பூஜ்ஜியத்தை விட அதிகமாக இருக்க வேண்டும்.");
      return;
    }

    try {
      setLoading(true);
      await onSaveEntry({
        type,
        date,
        category,
        amount: amtNum,
        description: description.trim(),
      });

      // Clear form except date
      setAmount("");
      setDescription("");
      setSuccess(true);
      setError("");
      setTimeout(() => {
        setSuccess(false);
      }, 4000);
    } catch (err: any) {
      setError("பதிவு சேமிப்பதில் பிழை: " + (err.message || err));
    } finally {
      setLoading(false);
    }
  };

  // Get max date allowed (today)
  const getMaxDateStr = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, "0");
    const dd = String(today.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };

  return (
    <div className="w-full max-w-lg mx-auto font-sans px-2 py-4">
      {/* Page Title */}
      <div className="mb-6 text-center">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">புது வரவு/செலவு பதிவு</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">மசூதி வரவு அல்லது செலவை உடனுக்குடன் பதியலாம்</p>
      </div>

      {/* Entry Form Card */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-md border border-slate-100 dark:border-slate-800 p-5 relative transition-colors">
        {success && (
          <div className="mb-4 flex items-center justify-between p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 rounded-xl border border-emerald-200 dark:border-emerald-900/40 animate-fadeIn">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
              <span className="text-sm font-bold">பதிவு சேமிக்கப்பட்டது ✓</span>
            </div>
            <button onClick={() => setSuccess(false)} className="text-emerald-700 dark:text-emerald-400 cursor-pointer">
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-rose-50 dark:bg-rose-950/20 text-rose-800 dark:text-rose-300 text-xs rounded-xl border border-rose-200 dark:border-rose-900/40">
            {error}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-5">
          {/* Two Big Toggle Buttons at Top */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setType("income")}
              className={`py-3.5 px-4 rounded-xl text-center font-bold text-sm transition-all shadow-sm cursor-pointer ${
                type === "income"
                  ? "bg-[#1D9E75] text-white ring-2 ring-emerald-500/10 scale-[1.02]"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              வருமானம் (Income)
            </button>
            <button
              type="button"
              onClick={() => setType("expense")}
              className={`py-3.5 px-4 rounded-xl text-center font-bold text-sm transition-all shadow-sm cursor-pointer ${
                type === "expense"
                  ? "bg-rose-600 text-white ring-2 ring-rose-500/10 scale-[1.02]"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              செலவு (Expense)
            </button>
          </div>

          <hr className="border-slate-100 dark:border-slate-800" />

          {/* 1. தேதி (Date Picker) */}
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider">
              1. தேதி (Date) *
            </label>
            <div className="relative rounded-xl shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-4 w-4 text-slate-400 dark:text-slate-500" />
              </div>
              <input
                type="date"
                required
                max={getMaxDateStr()}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-850 dark:text-slate-100"
              />
            </div>
          </div>

          {/* 2. வகை (Category) Dropdown */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                2. வகை (Category) *
              </label>
              <span className="text-[10px] text-slate-400 dark:text-slate-300 font-semibold bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full transition-colors">
                {selectedMonth === "" ? "" : selectedMonth} மாதம்
              </span>
            </div>
            <select
              value={category}
              onChange={handleCategoryChange}
              className="block w-full px-3 py-2.5 border border-slate-200 dark:border-slate-705 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white dark:bg-slate-800 text-sm text-slate-850 dark:text-slate-100"
            >
              {availableCategories.map((catName) => (
                <option key={catName} value={catName}>
                  {catName}
                </option>
              ))}
              <option value="add_new_temp" className="text-[#1D9E75] dark:text-[#10b981] font-bold">
                + புதிய வகை சேர் (Add temporary category)
              </option>
            </select>
          </div>

          {/* 3. தொகை (Amount) Input */}
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider">
              3. தொகை (Amount - ₹) *
            </label>
            <div className="relative rounded-xl shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                <span className="text-slate-500 dark:text-slate-400 font-extrabold text-base">₹</span>
              </div>
              <input
                type="number"
                min="1"
                step="any"
                required
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const val = e.target.value;
                  setAmount(val === "" ? "" : Math.abs(parseFloat(val)));
                }}
                className="block w-full pl-8 pr-3 py-2.5 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-bold text-slate-850 dark:text-slate-100"
              />
            </div>
          </div>

          {/* 4. விவரம் (Description) Area */}
          <div>
            <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1.5 uppercase tracking-wider">
              4. விவரம் (Description)
            </label>
            <div className="relative rounded-xl shadow-sm">
              <div className="absolute top-3 left-3 pointer-events-none">
                <FileText className="h-4 w-4 text-slate-400 dark:text-slate-500" />
              </div>
              <textarea
                rows={3}
                placeholder="இந்த பதிவு பற்றிய விவரம்..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="block w-full pl-9 pr-3 py-2.5 border border-slate-200 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-850 dark:text-slate-100"
              />
            </div>
          </div>

          {/* Save Button */}
          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3.5 px-4 font-bold border border-transparent rounded-xl shadow-md text-sm text-white transition-all bg-[#1D9E75] hover:bg-[#158060] dark:bg-emerald-600 dark:hover:bg-emerald-750 cursor-pointer ${
              loading ? "opacity-70 cursor-not-allowed" : ""
            }`}
          >
            {loading ? "சேமிக்கப்படுகிறது..." : "சேமி (Save Entry)"}
          </button>
        </form>
      </div>

      {/* Category Creation Popup Modal */}
      {showPopup && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-sm border border-slate-150 dark:border-slate-800 p-6 overflow-hidden animate-slideUp">
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-slate-100 text-base">புதிய தற்காலிக வகை</h3>
              <button
                onClick={() => {
                  setShowPopup(false);
                  setNewCatName("");
                  setPopupError("");
                  // reset dropdown to first category
                  if (availableCategories.length > 0) setCategory(availableCategories[0]);
                }}
                className="text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-350 cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {popupError && (
              <div className="mt-3 p-2 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-xs rounded-xl">
                {popupError}
              </div>
            )}

            <form onSubmit={handleAddTempCategorySubmit} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 dark:text-slate-400 mb-1 uppercase">
                  வகை பெயர் (Tamil Name)
                </label>
                <input
                  type="text"
                  required
                  placeholder="எ.கா. நோன்பு கஞ்சி செலவு"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="block w-full px-3 py-2.5 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-850 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 rounded-xl text-[10px] space-y-1">
                <p className="font-semibold text-slate-705 dark:text-slate-300 flex items-center">
                  <HelpCircle className="h-3 w-3 mr-1 text-[#1D9E75] dark:text-[#10b981]" />
                  தற்காலிக வகைக்கான விதிமுறை:
                </p>
                <p>• இது தற்போதைய மாதத்திற்கு ({selectedMonth}) மட்டும் பொருந்தும்.</p>
                <p>• மற்ற மாதங்கள் அல்லது பள்ளிவாசல்களுக்கு இதில் தெரியாது.</p>
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowPopup(false);
                    setNewCatName("");
                    setPopupError("");
                    if (availableCategories.length > 0) setCategory(availableCategories[0]);
                  }}
                  className="px-3 py-2 text-xs font-medium text-slate-600 dark:text-slate-350 bg-slate-150 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
                >
                  ரத்து செய்
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-3 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-750 rounded-xl shadow-sm transition-colors cursor-pointer"
                >
                  {loading ? "சேர்க்கிறது..." : "வகை சேர்க்கவும்"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

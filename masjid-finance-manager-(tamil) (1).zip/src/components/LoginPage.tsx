import React, { useState } from "react";
import { Mail, Lock, User, Phone, ShieldCheck } from "lucide-react";

interface LoginPageProps {
  onLogin: (userData: {
    uid: string;
    name: string;
    email: string;
    phone?: string;
  }) => void;
  isFirebaseConfigured: boolean;
}

export default function LoginPage({ onLogin, isFirebaseConfigured }: LoginPageProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError("");
    try {
      if (isFirebaseConfigured) {
        const { auth, db } = await import("../firebase");
        const { GoogleAuthProvider, signInWithPopup } = await import("firebase/auth");
        const provider = new GoogleAuthProvider();
        const result = await signInWithPopup(auth, provider);
        const user = result.user;

        onLogin({
          uid: user.uid,
          name: user.displayName || "அறியப்படாத பயனர்",
          email: user.email || "",
          phone: user.phoneNumber || "",
        });
      } else {
        // High fidelity simulated login
        setTimeout(() => {
          onLogin({
            uid: "simulated-google-user",
            name: "டெமோ கூகிள் பயனர்",
            email: "demo.masjid@gmail.com",
            phone: "+91 98765 43210",
          });
          setLoading(false);
        }, 800);
      }
    } catch (err: any) {
      console.error(err);
      setError("கூகிள் புகுபதிவு தோல்வியடைந்தது: " + (err.message || err));
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (isSignUp && !name)) {
      setError("அனைத்து கட்டாய புலங்களையும் நிரப்புக.");
      return;
    }
    setLoading(true);
    setError("");

    try {
      if (isFirebaseConfigured) {
        const { auth } = await import("../firebase");
        const {
          signInWithEmailAndPassword,
          createUserWithEmailAndPassword,
          updateProfile,
        } = await import("firebase/auth");

        if (isSignUp) {
          const result = await createUserWithEmailAndPassword(auth, email, password);
          await updateProfile(result.user, { displayName: name });
          onLogin({
            uid: result.user.uid,
            name: name,
            email: email,
            phone: phone,
          });
        } else {
          const result = await signInWithEmailAndPassword(auth, email, password);
          onLogin({
            uid: result.user.uid,
            name: result.user.displayName || "பயனர்",
            email: email,
          });
        }
      } else {
        // High-fidelity local simulation
        setTimeout(() => {
          onLogin({
            uid: `simulated-user-${Date.now()}`,
            name: isSignUp ? name : "டெமோ பள்ளிவாசல் பயனர்",
            email: email,
            phone: phone,
          });
          setLoading(false);
        }, 800);
      }
    } catch (err: any) {
      console.error(err);
      setError("முறையற்ற தகவல் அல்லது கணக்கு பிழை: " + (err.message || "முயற்சி தோல்வியடைந்தது"));
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans transition-colors duration-200 text-slate-900 dark:text-slate-100">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="mx-auto h-16 w-16 bg-[#1D9E75] text-white rounded-2xl flex items-center justify-center shadow-lg transform rotate-6 hover:rotate-12 transition-transform">
          <ShieldCheck className="h-10 w-10" />
        </div>
        <h2 className="mt-4 text-center text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100 leading-snug">
          மஸ்ஜித் நிதி மேலாண்மை
        </h2>
        <p className="mt-2 text-center text-sm text-slate-600 dark:text-slate-400">
          Masjid Finance Tracker • மசூதி வரவு செலவு கணக்கு
        </p>

        {!isFirebaseConfigured && (
          <div className="mt-4 mx-4 p-3 bg-amber-50/15 dark:bg-amber-950/20 text-amber-800 dark:text-amber-300 text-xs rounded-xl border border-amber-200/50 dark:border-amber-800/40 text-left">
            <p className="font-semibold">⚠️ டெமோ (ஆஃப்லைன்) பயன்முறை செயல்பாடு:</p>
            <p className="mt-1">
              ஃபயர்பேஸ் முழுமையாக கட்டமைக்கப்படவில்லை. தங்களின் வசதிக்காக, லோக்கல் ஸ்டோரேஜ் மூலம் கணக்கு துவங்கப்பட்டு முழுமையாக சோதிக்க முடியும்.
            </p>
          </div>
        )}
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md mx-4">
        <div className="bg-white dark:bg-slate-900 py-8 px-6 shadow-xl rounded-2xl border border-slate-100 dark:border-slate-800 transition-colors">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 dark:bg-rose-950/35 border border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-sm rounded-xl">
              {error}
            </div>
          )}

          <form className="space-y-4" onSubmit={handleSubmit}>
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">பெயர் (Full Name) *</label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                  </div>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required={isSignUp}
                    placeholder="உமது பெயர்"
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1D9E75] focus:border-transparent text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">மின்னஞ்சல் முகவரி (Email Address) *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="name@example.com"
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1D9E75] focus:border-transparent text-sm text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">தொலைபேசி எண் (Phone Number) </label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Phone className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                  </div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 99999 99999"
                    className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1D9E75] focus:border-transparent text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">கடவுச்சொல் (Password) *</label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-slate-400 dark:text-slate-550" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                  className="block w-full pl-10 pr-3 py-2.5 border border-slate-300 dark:border-slate-705 bg-white dark:bg-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#1D9E75] focus:border-transparent text-sm text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-[#1D9E75] hover:bg-[#158060] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1D9E75] transition-colors cursor-pointer"
              >
                {loading ? "செயலாக்கப்படுகிறது..." : isSignUp ? "கணக்கு உருவாக்கு" : "புகுபதிவு செய்"}
              </button>
            </div>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-white dark:bg-slate-900 px-2 text-slate-500 dark:text-slate-400">அல்லது</span>
              </div>
            </div>

            <div className="mt-4">
              <button
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full flex items-center justify-center py-2.5 px-4 border border-slate-300 dark:border-slate-700 rounded-xl shadow-sm text-sm font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#1D9E75]"
              >
                <img
                  className="h-5 w-5 mr-2"
                  src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                  alt="Google"
                />
                Gmail கொண்டு புகுபதிவு
              </button>
            </div>
          </div>

          <div className="mt-6 text-center text-sm text-slate-600 dark:text-slate-400">
            {isSignUp ? "ஏற்கனவே கணக்கு உள்ளதா?" : "புதிய கணக்கு வேண்டுமா?"}{" "}
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="font-medium text-[#1D9E75] hover:text-[#158060] cursor-pointer"
            >
              {isSignUp ? "புகுபதிவு செய்க" : "இங்கே உருவாக்குங்கள்"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import React from "react";

interface LoaderProps {
  message?: string;
}

export default function Loader({ message = "ஏற்றப்படுகிறது..." }: LoaderProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="w-12 h-12 border-4 border-emerald-100 border-t-emerald-600 rounded-full animate-spin"></div>
      <p className="mt-4 text-sm text-emerald-700 font-medium animate-pulse">{message}</p>
    </div>
  );
}

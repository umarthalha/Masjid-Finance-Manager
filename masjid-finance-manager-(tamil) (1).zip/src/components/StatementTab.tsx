import React, { useState, useMemo } from "react";
import { FinanceEntry } from "../types";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Calendar, FileDown, ArrowRightLeft, TrendingUp, TrendingDown, Layers, FileText } from "lucide-react";

interface StatementTabProps {
  entries: FinanceEntry[];
  activeMasjidId: string;
  onSwitchTab: (tab: "entry" | "statement" | "category") => void;
  masjidName: string;
  masjidArea: string;
}

type PeriodType = "monthly" | "quarterly" | "yearly" | "custom";

export default function StatementTab({
  entries,
  activeMasjidId,
  onSwitchTab,
  masjidName,
  masjidArea,
}: StatementTabProps) {
  const [period, setPeriod] = useState<PeriodType>("monthly");
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  // Filter States
  const [selectedYear, setSelectedYear] = useState(() => String(new Date().getFullYear()));
  const [selectedMonth, setSelectedMonth] = useState(() => String(new Date().getMonth() + 1).padStart(2, "0"));
  const [selectedQuarter, setSelectedQuarter] = useState<"Q1" | "Q2" | "Q3" | "Q4">("Q1");
  const [fromDate, setFromDate] = useState(() => {
    const today = new Date();
    today.setDate(today.getDate() - 30);
    return today.toISOString().substring(0, 10);
  });
  const [toDate, setToDate] = useState(() => new Date().toISOString().substring(0, 10));

  // Options lists
  const yearsList = ["2024", "2025", "2026", "2027", "2028", "2029", "2530"];
  const monthsMap = [
    { value: "01", label: "ஜனவரி (January)" },
    { value: "02", label: "பிப்ரவரி (February)" },
    { value: "03", label: "மார்ச் (March)" },
    { value: "04", label: "ஏப்ரல் (April)" },
    { value: "05", label: "மே (May)" },
    { value: "06", label: "ஜூன் (June)" },
    { value: "07", label: "ஜூலை (July)" },
    { value: "08", label: "ஆகஸ்ட் (August)" },
    { value: "09", label: "செப்டம்பர் (September)" },
    { value: "10", label: "அக்டோபர் (October)" },
    { value: "11", label: "நவம்பர் (November)" },
    { value: "12", label: "டிசம்பர் (December)" },
  ];

  // Derive Period Display Name in Tamil
  const periodDisplayName = useMemo(() => {
    switch (period) {
      case "monthly": {
        const mLabel = monthsMap.find((m) => m.value === selectedMonth)?.label.split(" ")[0] || "";
        return `${mLabel} - ${selectedYear} (மாதாந்திர அறிக்கை)`;
      }
      case "quarterly":
        return `${selectedQuarter} - ${selectedYear} (காலாண்டு அறிக்கை)`;
      case "yearly":
        return `${selectedYear} (ஆண்டு அறிக்கை)`;
      case "custom":
        return `தேதி: ${formatTamilDate(fromDate)} முதல் ${formatTamilDate(toDate)} வரை`;
    }
  }, [period, selectedYear, selectedMonth, selectedQuarter, fromDate, toDate]);

  // Helper date formatter: DD/MM/YYYY
  function formatTamilDate(dateStr: string) {
    if (!dateStr) return "";
    const [y, m, d] = dateStr.split("-");
    return `${d}/${m}/${y}`;
  }

  // Format currency helpers
  function formatCurrency(num: number) {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
      .format(num)
      .replace("INR", "₹")
      .trim();
  }

  // Active Filtred Entries
  const filteredEntries = useMemo(() => {
    return entries.filter((entry) => {
      // Must match current mosque
      if (entry.masjidId !== activeMasjidId) return false;

      const entryDate = entry.date; // YYYY-MM-DD
      const [entryYear, entryMonth] = entryDate.split("-");

      if (period === "monthly") {
        return entryYear === selectedYear && entryMonth === selectedMonth;
      } else if (period === "quarterly") {
        const monthNum = parseInt(entryMonth, 10);
        let q = "";
        if (monthNum >= 1 && monthNum <= 3) q = "Q1";
        else if (monthNum >= 4 && monthNum <= 6) q = "Q2";
        else if (monthNum >= 7 && monthNum <= 9) q = "Q3";
        else if (monthNum >= 10 && monthNum <= 12) q = "Q4";

        return entryYear === selectedYear && q === selectedQuarter;
      } else if (period === "yearly") {
        return entryYear === selectedYear;
      } else if (period === "custom") {
        return entryDate >= fromDate && entryDate <= toDate;
      }
      return false;
    });
  }, [entries, activeMasjidId, period, selectedYear, selectedMonth, selectedQuarter, fromDate, toDate]);

  // Calculate totals
  const totals = useMemo(() => {
    let income = 0;
    let expense = 0;
    filteredEntries.forEach((entry) => {
      if (entry.type === "income") {
        income += entry.amount;
      } else {
        expense += entry.amount;
      }
    });
    return {
      income,
      expense,
      net: income - expense,
    };
  }, [filteredEntries]);

  // PDF Report Downloader using html2canvas to preserve Tamil font beautifully
  const generatePDFReport = () => {
    setIsGeneratingPDF(true);
    setTimeout(() => {
      const element = document.getElementById("statement-pdf-template");
      if (!element) {
        setIsGeneratingPDF(false);
        return;
      }

      // Temporarily strip oklch declarations from all styles to avoid html2canvas oklch parsing errors
      const stylesToRestore: { element: HTMLStyleElement; rawContent: string }[] = [];
      try {
        document.querySelectorAll("style").forEach((styleEl) => {
          if (styleEl.innerHTML.includes("oklch")) {
            stylesToRestore.push({
              element: styleEl,
              rawContent: styleEl.innerHTML,
            });
            // Convert oklch to standard css-compliant hsl / hsla format
            const originalText = styleEl.innerHTML;
            let cleanText = originalText.replace(
              /oklch\s*\(\s*([0-9.]+%?)\s+([0-9.]+)\s+([0-9.]+)(?:\s*\/\s*([0-9.]+%?))?\s*\)/gi,
              (match, l, c, h, a) => {
                let lightnessVal = parseFloat(l);
                if (!l.includes("%") && lightnessVal <= 1.0) {
                  lightnessVal = lightnessVal * 100;
                }
                const chromaVal = parseFloat(c);
                const hueVal = parseFloat(h);
                // Saturation approximation: C * 250 clamped to 100
                const saturationVal = Math.min(100, Math.max(0, chromaVal * 250));
                if (a !== undefined) {
                  return `hsla(${hueVal}, ${saturationVal.toFixed(1)}%, ${lightnessVal.toFixed(1)}%, ${a})`;
                } else {
                  return `hsl(${hueVal}, ${saturationVal.toFixed(1)}%, ${lightnessVal.toFixed(1)}%)`;
                }
              }
            );
            // Fallback for any unmatched oklch definitions to flat black to ensure parsing never fails
            cleanText = cleanText.replace(/oklch\s*\([^)]+\)/gi, "rgb(0, 0, 0)");
            styleEl.innerHTML = cleanText;
          }
        });
      } catch (e) {
        console.warn("Failed to sanitize oklch styles:", e);
      }

      html2canvas(element, {
        scale: 2, // High resolution crisp text rendering
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
      })
        .then((canvas) => {
          // Restore original oklch styling immediately after capture completes
          stylesToRestore.forEach(({ element, rawContent }) => {
            element.innerHTML = rawContent;
          });

          const imgData = canvas.toDataURL("image/png");
          const pdf = new jsPDF({
            orientation: "p",
            unit: "mm",
            format: "a4",
          });

          const imgWidth = 190; // Left margin of 10mm, right of 10mm
          const pageHeight = 287; // mm height
          const imgHeight = (canvas.height * imgWidth) / canvas.width;
          let heightLeft = imgHeight;
          let position = 10; // Top margin

          pdf.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;

          while (heightLeft >= 0) {
            position = heightLeft - imgHeight + 10;
            pdf.addPage();
            pdf.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
          }

          pdf.save(`Masjid_Report_${period}_${selectedYear}.pdf`);
          setIsGeneratingPDF(false);
        })
        .catch((err) => {
          // Restore original style in case of errors
          stylesToRestore.forEach(({ element, rawContent }) => {
            element.innerHTML = rawContent;
          });
          console.error("Failed to generate PDF:", err);
          setIsGeneratingPDF(false);
        });
    }, 150);
  };

  // Browser's pristine native print system supporting direct Unicode translation perfectly!
  const triggerBrowserPrint = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-4xl mx-auto font-sans px-2 py-4">
      {/* Search Period Header Buttons */}
      <div className="mb-6 grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={() => setPeriod("monthly")}
          className={`py-2 px-3 border text-xs font-bold rounded-xl text-center cursor-pointer transition-all ${
            period === "monthly"
              ? "bg-[#1D9E75] text-white border-transparent shadow-sm"
              : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
          }`}
        >
          மாத அறிக்கை (Monthly)
        </button>
        <button
          onClick={() => setPeriod("quarterly")}
          className={`py-2 px-3 border text-xs font-bold rounded-xl text-center cursor-pointer transition-all ${
            period === "quarterly"
              ? "bg-[#1D9E75] text-white border-transparent shadow-sm"
              : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
          }`}
        >
          காலாண்டு அறிக்கை (Quarterly)
        </button>
        <button
          onClick={() => setPeriod("yearly")}
          className={`py-2 px-3 border text-xs font-bold rounded-xl text-center cursor-pointer transition-all ${
            period === "yearly"
              ? "bg-[#1D9E75] text-white border-transparent shadow-sm"
              : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
          }`}
        >
          ஆண்டு அறிக்கை (Yearly)
        </button>
        <button
          onClick={() => setPeriod("custom")}
          className={`py-2 px-3 border text-xs font-bold rounded-xl text-center cursor-pointer transition-all ${
            period === "custom"
              ? "bg-[#1D9E75] text-white border-transparent shadow-sm"
              : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800"
          }`}
        >
          தேதி வரம்பு (Custom Range)
        </button>
      </div>

      {/* Dynamic Filters Form */}
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-xs border border-slate-100 dark:border-slate-800 p-4 mb-6 transition-colors">
        <div className="flex flex-col sm:flex-row gap-4 items-end">
          {period === "monthly" && (
            <>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">மாதம் (Select Month)</label>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                >
                  {monthsMap.map((m) => (
                    <option key={m.value} value={m.value}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">வருடம் (Select Year)</label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                >
                  {yearsList.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </>
          )}

          {period === "quarterly" && (
            <>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">காலாண்டு (Select Quarter)</label>
                <select
                  value={selectedQuarter}
                  onChange={(e) => setSelectedQuarter(e.target.value as any)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                >
                  <option value="Q1">Q1 (ஜனவரி - மார்ச்)</option>
                  <option value="Q2">Q2 (ஏப்ரல் - ஜூன்)</option>
                  <option value="Q3">Q3 (ஜூலை - செப்டம்பர்)</option>
                  <option value="Q4">Q4 (அக்டோபர் - டிசம்பர்)</option>
                </select>
              </div>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">வருடம் (Select Year)</label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                >
                  {yearsList.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </>
          )}

          {period === "yearly" && (
            <div className="flex-1 w-full">
              <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">வருடம் (Select Year)</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
              >
                {yearsList.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
          )}

          {period === "custom" && (
            <>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">முதல் தேதி (From Date)</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                />
              </div>
              <div className="flex-1 w-full">
                <label className="block text-xs font-bold text-slate-550 dark:text-slate-400 mb-1">வரை தேதி (To Date)</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="block w-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-100"
                />
              </div>
            </>
          )}
        </div>
      </div>

      {/* Summary report details printing wrapper */}
      <div id="print-area-wrapper" className={`space-y-6 ${isGeneratingPDF ? "bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-slate-900" : ""}`}>
        {/* Printable Mosque Header */}
        <div className={`${isGeneratingPDF ? "block border-b border-slate-200 pb-4 mb-6" : "hidden print:block"} text-center`}>
          <h2 className="text-xl font-extrabold text-[#0f172a]">{masjidName}</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mt-1">{masjidArea}</p>
          <p className="text-sm text-[#1D9E75] font-bold mt-2">நிதி நிலை அறிக்கை (Financial Statement)</p>
          <p className="text-xs text-slate-400 font-semibold mt-1">காலவரம்பு (Period): {periodDisplayName}</p>
        </div>

        {/* Selected Period Display Badge */}
        <div className="print:hidden flex items-center space-x-2 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 px-4 py-3 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
          <Calendar className="h-5 w-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <div className="text-sm">
            <span className="font-bold">தேர்ந்தெடுக்கப்பட்ட காலம்:</span>{" "}
            <span className="font-semibold text-emerald-700 dark:text-emerald-400 bg-white dark:bg-slate-800 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-900/40 ml-1">
              {periodDisplayName}
            </span>
          </div>
        </div>

        {/* PAGE 2 — Summary Box (Cards layout) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Total Income in green */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center justify-between transition-colors">
            <div>
              <p className="text-xs text-slate-400 dark:text-slate-550 font-bold uppercase tracking-wider">மொத்த வருமானம் (Income)</p>
              <p className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1.5">{formatCurrency(totals.income)}</p>
            </div>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-955/30 rounded-xl text-emerald-600 dark:text-emerald-400">
              <TrendingUp className="h-6 w-6" />
            </div>
          </div>

          {/* Total Expense in red */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center justify-between transition-colors">
            <div>
              <p className="text-xs text-slate-400 dark:text-slate-550 font-bold uppercase tracking-wider">மொத்த செலவு (Expense)</p>
              <p className="text-2xl font-extrabold text-[#DC2626] dark:text-rose-400 mt-1.5">{formatCurrency(totals.expense)}</p>
            </div>
            <div className="p-3 bg-rose-50 dark:bg-rose-955/30 rounded-xl text-rose-600 dark:text-rose-400">
              <TrendingDown className="h-6 w-6" />
            </div>
          </div>

          {/* Net Balance */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 shadow-xs border border-slate-100 dark:border-slate-800 flex items-center justify-between transition-colors">
            <div>
              <p className="text-xs text-slate-400 dark:text-slate-550 font-bold uppercase tracking-wider">நிகர இருப்பு (Net Balance)</p>
              <p
                className={`text-2xl font-extrabold mt-1.5 ${
                  totals.net >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-[#DC2626]"
                }`}
              >
                {formatCurrency(totals.net)}
              </p>
            </div>
            <div className={`p-3 rounded-xl ${totals.net >= 0 ? "bg-emerald-50 dark:bg-emerald-955/30 text-emerald-600 dark:text-emerald-400" : "bg-rose-50 dark:bg-rose-955/30 text-rose-600 dark:text-rose-400"}`}>
              <ArrowRightLeft className="h-6 w-6" />
            </div>
          </div>
        </div>

        {/* Action button bar */}
        <div className="print:hidden flex flex-wrap gap-2 justify-end">
          <button
            onClick={() => onSwitchTab("category")}
            className="inline-flex items-center px-4 py-2.5 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-905 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Layers className="h-4 w-4 mr-1.5 text-[#1D9E75] dark:text-emerald-400" />
            வகை வாரியான அறிக்கை (Category Wise)
          </button>
          <button
            onClick={triggerBrowserPrint}
            className="inline-flex items-center px-4 py-2.5 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-905 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <FileText className="h-4 w-4 mr-1.5 text-blue-600 dark:text-blue-400" />
            அறிக்கையை அச்சிடுக (Print Report)
          </button>
          <button
            onClick={generatePDFReport}
            className="inline-flex items-center px-4 py-2.5 border border-transparent rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-colors cursor-pointer animate-pulse"
          >
            <FileDown className="h-4 w-4 mr-1.5" />
            PDF பதிவிறக்கம் (Download PDF)
          </button>
        </div>

        {/* Full itemised table */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 p-4 shadow-sm transition-colors">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              பதிவுகளின் விவரம் ({filteredEntries.length})
            </h3>
            <span className="text-[10px] bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full text-slate-500 font-semibold print:hidden">
              Statement Logs
            </span>
          </div>

          {filteredEntries.length === 0 ? (
            <div className="text-center py-10 text-slate-400 dark:text-slate-500 text-sm">
              இந்த காலவரம்பில் எந்த வரவு செலவு பதிவுகளும் பதியப்படவில்லை.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-slate-100 dark:border-slate-800">
              <table className="min-w-full divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                <thead className="bg-slate-50 dark:bg-slate-850">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-bold text-slate-550 dark:text-slate-400 uppercase tracking-wider">
                      தேதி
                    </th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-bold text-slate-550 dark:text-slate-400 uppercase tracking-wider">
                      வகை
                    </th>
                    <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-slate-550 dark:text-slate-400 uppercase tracking-wider">
                      வருமானம்
                    </th>
                    <th scope="col" className="px-4 py-3 text-right text-xs font-bold text-slate-550 dark:text-slate-400 uppercase tracking-wider">
                      செலவு
                    </th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-bold text-slate-550 dark:text-slate-400 uppercase tracking-wider">
                      விவரம்
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-100">
                  {filteredEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-3 whitespace-nowrap text-slate-600 font-mono text-xs">
                        {formatTamilDate(entry.date)}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap font-semibold text-slate-800">
                        {entry.category}
                      </td>
                      <td className={`px-4 py-3 whitespace-nowrap text-right font-extrabold ${entry.type === "income" ? "text-emerald-600" : "text-slate-300"}`}>
                        {entry.type === "income" ? formatCurrency(entry.amount) : "—"}
                      </td>
                      <td className={`px-4 py-3 whitespace-nowrap text-right font-extrabold ${entry.type === "expense" ? "text-rose-600" : "text-slate-300"}`}>
                        {entry.type === "expense" ? formatCurrency(entry.amount) : "—"}
                      </td>
                      <td className="px-4 py-3 text-slate-500 text-xs max-w-xs truncate">
                        {entry.description || "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Small print-only footer */}
        <div className="hidden print:block text-center text-[10px] text-slate-400 pt-8 border-t">
          அறிக்கை உருவாக்கிய தேதி: {new Date().toLocaleDateString("en-IN")} | பள்ளிவாசல் நிதி அறிக்கை
        </div>
      </div>

      {/* PERFECT PIXEL HIGH-FIDELITY PRIVATE PDF TEMPLATE */}
      {isGeneratingPDF && (
        <div
          id="statement-pdf-template"
          style={{
            position: "absolute",
            left: "-9999px",
            top: "0px",
            width: "800px",
            boxSizing: "border-box",
            padding: "45px 50px",
            background: "#ffffff",
            color: "#1e293b",
            fontSize: "14px",
          }}
          className="font-sans"
        >
          {/* Main Content Layout */}
          <div className="w-full">
            {/* Elegant Header Accent Brand Band */}
            <div className="h-2 bg-[#1D9E75] w-full rounded-t-lg mb-6"></div>

            {/* Split Header Info Details */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-2xl font-extrabold text-[#0f172a] tracking-tight">{masjidName}</h1>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">{masjidArea}</p>
                <div className="mt-4 flex items-center space-x-2 text-xs text-slate-400">
                  <span className="font-bold">அறிக்கை தேதி (Date):</span>
                  <span>{new Date().toLocaleDateString("en-IN", { day: '2-digit', month: '2-digit', year: 'numeric' })}</span>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-[#E6F5F0] text-[#1D9E75] font-extrabold text-[10px] uppercase px-3 py-1 rounded-full mb-1">
                  OFFICIAL STATEMENT
                </span>
                <p className="text-lg font-extrabold text-slate-800">நிதி நிலை அறிக்கை</p>
                <p className="text-xs text-slate-400 font-bold mt-1">காலவரம்பு: {periodDisplayName}</p>
              </div>
            </div>

            {/* Subtle Divider Rule Line */}
            <div className="border-b border-slate-200 mb-8"></div>

            {/* Financial Summary Executive Stats Widgets Grid */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              {/* Total Income */}
              <div style={{ borderColor: '#e2e8f0', borderWidth: '1px', borderStyle: 'solid' }} className="rounded-2xl p-5 bg-[#FDFDFD]">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">மொத்த வரவு (Income)</p>
                <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Total Income</p>
                <p className="text-2xl font-extrabold text-[#10B981] mt-3">{formatCurrency(totals.income)}</p>
              </div>

              {/* Total Expense */}
              <div style={{ borderColor: '#e2e8f0', borderWidth: '1px', borderStyle: 'solid' }} className="rounded-2xl p-5 bg-[#FDFDFD]">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">மொத்த செலவு (Expense)</p>
                <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Total Expense</p>
                <p className="text-2xl font-extrabold text-[#EF4444] mt-3">{formatCurrency(totals.expense)}</p>
              </div>

              {/* Net Balance */}
              <div style={{ borderColor: '#e2e8f0', borderWidth: '1px', borderStyle: 'solid' }} className="rounded-2xl p-5 bg-[#FDFDFD]">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">நிகர இருப்பு (Balance)</p>
                <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Net Balance</p>
                <p className={`text-2xl font-extrabold mt-3 ${totals.net >= 0 ? "text-[#10B981]" : "text-[#EF4444]"}`}>
                  {formatCurrency(totals.net)}
                </p>
              </div>
            </div>

            {/* Ledger Itemisation Block Header */}
            <div className="flex justify-between items-center bg-[#F8FAFC] border-t border-b border-slate-200 px-4 py-3 mb-4">
              <span className="text-xs font-extrabold text-slate-500 uppercase tracking-widest">
                Ledger Entries / பதிவுகளின் விவரம்
              </span>
              <span className="text-xs font-bold text-[#1D9E75]">
                {filteredEntries.length} பதிவுகள்
              </span>
            </div>

            {/* Beautiful Printed Ledger Table */}
            {filteredEntries.length === 0 ? (
              <p className="text-center text-slate-400 py-12 text-sm italic">
                இந்த காலவரம்பில் எந்த வரவு செலவு பதிவுகளும் பதியப்படவில்லை.
              </p>
            ) : (
              <div style={{ borderColor: '#f1f5f9', borderWidth: '1px', borderStyle: 'solid' }} className="rounded-xl overflow-hidden mb-12">
                <table className="min-w-full divide-y divide-[#f1f5f9] text-[13px]">
                  <thead className="bg-[#F8FAFC]">
                    <tr>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-left font-bold text-xs uppercase tracking-wider">தேதி</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-left font-bold text-xs uppercase tracking-wider">வகை</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-right font-bold text-xs uppercase tracking-wider">வரவு (₹)</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-right font-bold text-xs uppercase tracking-wider">செலவு (₹)</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-left font-bold text-xs uppercase tracking-wider">விவரம்</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-[#f1f5f9]">
                    {filteredEntries.map((entry, idx) => (
                      <tr key={entry.id} className={idx % 2 === 0 ? "bg-white" : "bg-[#FCFDFE]"}>
                        <td className="px-5 py-3.5 whitespace-nowrap text-slate-500 font-mono text-xs">{formatTamilDate(entry.date)}</td>
                        <td className="px-5 py-3.5 whitespace-nowrap font-semibold text-slate-800">{entry.category}</td>
                        <td className="px-5 py-3.5 whitespace-nowrap text-right font-extrabold text-[#10B981]">
                          {entry.type === "income" ? formatCurrency(entry.amount) : "—"}
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap text-right font-extrabold text-[#EF4444]">
                          {entry.type === "expense" ? formatCurrency(entry.amount) : "—"}
                        </td>
                        <td style={{ color: '#64748b' }} className="px-5 py-3.5 text-slate-500 text-xs max-w-xs truncate">{entry.description || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Official Audit Closure / Signature Sign-off Lines */}
            <div className="grid grid-cols-2 gap-12 mt-16 pt-12 border-t border-slate-100 mb-8" style={{ pageBreakBefore: 'avoid' }}>
              <div className="text-center">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">தயாரித்தவர் (Prepared By)</p>
                <div className="mt-14 border-b border-dashed border-slate-300 mx-10"></div>
                <p className="text-[11px] font-bold text-slate-400 mt-2">பள்ளிவாசல் பொருளாளர் / Treasurer</p>
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">ஒப்புதல் அளித்தவர் (Approved By)</p>
                <div className="mt-14 border-b border-dashed border-slate-300 mx-10"></div>
                <p className="text-[11px] font-bold text-slate-400 mt-2">பள்ளிவாசல் தலைவர் / President</p>
               </div>
            </div>

            {/* Watermark Branding */}
            <div className="text-center text-[10px] text-slate-300 font-bold tracking-widest mt-12 uppercase">
              MASJID ACCOUNTS OFFICIAL GENERAL REPORT
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React, { useState, useMemo } from "react";
import { FinanceEntry, TempCategory } from "../types";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { Check, Calendar, FileDown, FolderOpen, PieChart, Layers } from "lucide-react";

interface CategoryTabProps {
  entries: FinanceEntry[];
  tempCategories: TempCategory[];
  activeMasjidId: string;
  masjidName: string;
  masjidArea: string;
}

type PeriodType = "monthly" | "quarterly" | "yearly" | "custom";

export default function CategoryTab({
  entries,
  tempCategories,
  activeMasjidId,
  masjidName,
  masjidArea,
}: CategoryTabProps) {
  const [period, setPeriod] = useState<PeriodType>("monthly");
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  // Filter States
  const [selectedYear, setSelectedYear] = useState(() => String(new Date().getFullYear()));
  const [selectedMonth, setSelectedMonth] = useState(() => String(new Date().getMonth() + 1).padStart(2, "0"));
  const [selectedQuarter, setSelectedQuarter] = useState<"Q1" | "Q2" | "Q3" | "Q4">("Q1");
  const [fromDate, setFromDate] = useState(() => {
    const today = new Date();
    today.setDate(today.getDate() - 30);
    return today.toISOString().substring(0, 10);
  });
  const [toDate, setToDate] = useState(() => new Date().toISOString().substring(0, 10));

  // Category Checkbox Selection
  // Extract all categories of the active masjid dynamically
  const availableCategories = useMemo(() => {
    const baseList = [
      "ஆரம்ப இருப்பு (மாதத்திற்கான)",
      "Rent Shop 1",
      "Rent Shop 2",
      "Rent Shop 3",
      "Rent Shop 4",
      "Rent Shop 5",
      "Rent Shop 6",
      "Rent Shop 7",
      "Rent Shop 8",
      "Rent Shop 9",
      "Rent Shop 10",
      "Rent Shop 11",
      "Rent Shop 12",
      "Rent Shop 13",
      "பாத்திர வாடகை வருமானம்",
      "நிக்காஹ் வசூல்",
      "நன்கொடை வசூல்",
      "ஹஸ்ரத் சம்பளம்",
      "மொதினார் / பிலால் சம்பளம்",
      "மின் கட்டணம்",
      "பஞ்சாயத்து வரி",
      "எழுதுபொருள் வாங்கியது",
      "மின் பொருள் வாங்கியது",
      "வக்ஃப் வரி"
    ];
    
    // Add custom cats from tempCategories
    const tempList = tempCategories
      .filter((cat) => cat.masjidId === activeMasjidId)
      .map((cat) => cat.name);

    // Add list from entries
    const entryList = entries
      .filter((e) => e.masjidId === activeMasjidId)
      .map((e) => e.category);

    const merged = [...baseList, ...tempList, ...entryList];
    return Array.from(new Set(merged)).filter(Boolean);
  }, [entries, tempCategories, activeMasjidId]);

  const [selectedCategories, setSelectedCategories] = useState<string[]>(() => [...availableCategories]);

  // Sync state if category list refreshes and nothing selected
  React.useEffect(() => {
    if (selectedCategories.length === 0 && availableCategories.length > 0) {
      setSelectedCategories(availableCategories);
    }
  }, [availableCategories]);

  // Options helpers
  const yearsList = ["2024", "2025", "2026", "2027", "2028", "2029", "2030"];
  const monthsMap = [
    { value: "01", label: "ஜனவரி (January)" },
    { value: "02", label: "பிப்ரவரி (February)" },
    { value: "03", label: "மார்ச் (March)" },
    { value: "04", label: "ஏப்ரல் (April)" },
    { value: "05", label: "மே (May)" },
    { value: "06", label: "ஜூன் (June)" },
    { value: "07", label: "ஜூலை (July)" },
    { value: "08", label: "ஆகஸ்ட் (August)" },
    { value: "09", label: "செப்டம்பர் (September)" },
    { value: "10", label: "அக்டோபர் (October)" },
    { value: "11", label: "நவம்பர் (November)" },
    { value: "12", label: "டிசம்பர் (December)" },
  ];

  // Formatting helper
  function formatCurrency(num: number) {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })
      .format(num)
      .replace("INR", "₹")
      .trim();
  }

  const periodDisplayName = useMemo(() => {
    switch (period) {
      case "monthly": {
        const mLabel = monthsMap.find((m) => m.value === selectedMonth)?.label.split(" ")[0] || "";
        return `${mLabel} - ${selectedYear}`;
      }
      case "quarterly":
        return `${selectedQuarter} - ${selectedYear}`;
      case "yearly":
        return `${selectedYear}`;
      case "custom":
        return `${fromDate} to ${toDate}`;
    }
  }, [period, selectedYear, selectedMonth, selectedQuarter, fromDate, toDate]);

  // Filter Entries strictly matching selecting period + SELECTED CATEGORIES
  const filteredEntries = useMemo(() => {
    return entries.filter((entry) => {
      // Must match current mosque
      if (entry.masjidId !== activeMasjidId) return false;

      // Must be inside selected categories
      if (!selectedCategories.includes(entry.category)) return false;

      const entryDate = entry.date;
      const [entryYear, entryMonth] = entryDate.split("-");

      if (period === "monthly") {
        return entryYear === selectedYear && entryMonth === selectedMonth;
      } else if (period === "quarterly") {
        const monthNum = parseInt(entryMonth, 10);
        let q = "";
        if (monthNum >= 1 && monthNum <= 3) q = "Q1";
        else if (monthNum >= 4 && monthNum <= 6) q = "Q2";
        else if (monthNum >= 7 && monthNum <= 9) q = "Q3";
        else if (monthNum >= 10 && monthNum <= 12) q = "Q4";

        return entryYear === selectedYear && q === selectedQuarter;
      } else if (period === "yearly") {
        return entryYear === selectedYear;
      } else if (period === "custom") {
        return entryDate >= fromDate && entryDate <= toDate;
      }
      return false;
    });
  }, [entries, activeMasjidId, selectedCategories, period, selectedYear, selectedMonth, selectedQuarter, fromDate, toDate]);

  // Category summaries: dynamic computing of totals per selected category
  const categorySummaries = useMemo(() => {
    const summaries: { [name: string]: { total: number; count: number; type: "income" | "expense" } } = {};

    selectedCategories.forEach((cat) => {
      summaries[cat] = { total: 0, count: 0, type: "income" };
    });

    filteredEntries.forEach((entry) => {
      if (summaries[entry.category]) {
        summaries[entry.category].total += entry.amount;
        summaries[entry.category].count += 1;
        summaries[entry.category].type = entry.type;
      }
    });

    return Object.entries(summaries).map(([name, stat]) => ({
      name,
      ...stat,
    }));
  }, [filteredEntries, selectedCategories]);

  // Toggle single category selection
  const handleToggleCategory = (catName: string) => {
    if (selectedCategories.includes(catName)) {
      setSelectedCategories(selectedCategories.filter((c) => c !== catName));
    } else {
      setSelectedCategories([...selectedCategories, catName]);
    }
  };

  const handleSelectAll = () => {
    setSelectedCategories([...availableCategories]);
  };

  const handleDeselectAll = () => {
    setSelectedCategories([]);
  };

  // Generate jsPDF Report specifically for Category view using html2canvas to preserve Tamil font beautifully
  const generateCategoryPDF = () => {
    setIsGeneratingPDF(true);
    setTimeout(() => {
      const element = document.getElementById("category-pdf-template");
      if (!element) {
        setIsGeneratingPDF(false);
        return;
      }

      // Temporarily strip oklch declarations from all styles to avoid html2canvas oklch parsing errors
      const stylesToRestore: { element: HTMLStyleElement; rawContent: string }[] = [];
      try {
        document.querySelectorAll("style").forEach((styleEl) => {
          if (styleEl.innerHTML.includes("oklch")) {
            stylesToRestore.push({
              element: styleEl,
              rawContent: styleEl.innerHTML,
            });
            // Convert oklch to standard css-compliant hsl / hsla format
            const originalText = styleEl.innerHTML;
            let cleanText = originalText.replace(
              /oklch\s*\(\s*([0-9.]+%?)\s+([0-9.]+)\s+([0-9.]+)(?:\s*\/\s*([0-9.]+%?))?\s*\)/gi,
              (match, l, c, h, a) => {
                let lightnessVal = parseFloat(l);
                if (!l.includes("%") && lightnessVal <= 1.0) {
                  lightnessVal = lightnessVal * 100;
                }
                const chromaVal = parseFloat(c);
                const hueVal = parseFloat(h);
                // Saturation approximation: C * 250 clamped to 100
                const saturationVal = Math.min(100, Math.max(0, chromaVal * 250));
                if (a !== undefined) {
                  return `hsla(${hueVal}, ${saturationVal.toFixed(1)}%, ${lightnessVal.toFixed(1)}%, ${a})`;
                } else {
                  return `hsl(${hueVal}, ${saturationVal.toFixed(1)}%, ${lightnessVal.toFixed(1)}%)`;
                }
              }
            );
            // Fallback for any unmatched oklch definitions to flat black to ensure parsing never fails
            cleanText = cleanText.replace(/oklch\s*\([^)]+\)/gi, "rgb(0, 0, 0)");
            styleEl.innerHTML = cleanText;
          }
        });
      } catch (e) {
        console.warn("Failed to sanitize oklch styles:", e);
      }

      html2canvas(element, {
        scale: 2, // High resolution crisp text rendering
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
      })
        .then((canvas) => {
          // Restore original oklch styling immediately after capture completes
          stylesToRestore.forEach(({ element, rawContent }) => {
            element.innerHTML = rawContent;
          });

          const imgData = canvas.toDataURL("image/png");
          const pdf = new jsPDF({
            orientation: "p",
            unit: "mm",
            format: "a4",
          });

          const imgWidth = 190; // Left margin of 10mm, right of 10mm
          const pageHeight = 287; // mm height
          const imgHeight = (canvas.height * imgWidth) / canvas.width;
          let heightLeft = imgHeight;
          let position = 10; // Top margin

          pdf.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;

          while (heightLeft >= 0) {
            position = heightLeft - imgHeight + 10;
            pdf.addPage();
            pdf.addImage(imgData, "PNG", 10, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
          }

          pdf.save(`Masjid_Category_Report_${selectedYear}.pdf`);
          setIsGeneratingPDF(false);
        })
        .catch((err) => {
          // Restore original style in case of errors
          stylesToRestore.forEach(({ element, rawContent }) => {
            element.innerHTML = rawContent;
          });
          console.error("Failed to generate PDF:", err);
          setIsGeneratingPDF(false);
        });
    }, 150);
  };

  return (
    <div id="category-print-area" className={`w-full max-w-4xl mx-auto font-sans px-2 py-4 ${isGeneratingPDF ? "bg-white p-6 rounded-2xl border" : ""}`}>
      {/* Printable Active Mosque Header */}
      {isGeneratingPDF && (
        <div className="text-center border-b border-slate-200 pb-4 mb-6">
          <h2 className="text-xl font-extrabold text-slate-900">{masjidName}</h2>
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mt-1">{masjidArea}</p>
          <p className="text-sm text-[#1D9E75] font-bold mt-2">வகை வாரியான நிதி அறிக்கை</p>
        </div>
      )}
      {/* Screen Title */}
      {!isGeneratingPDF && (
        <div className="mb-6 text-center">
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">வகை வாரியான நிதி அறிக்கை</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">குறிப்பிட்ட தலைப்புகள் மற்றும் காலவரம்புக்குள் நிதி விவரங்களை பகுப்பாய்வு செய்யலாம்</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Category checkboxes & Period selection */}
        <div className="lg:col-span-1 space-y-6 print:hidden no-pdf">
          {/* Period Selectors */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xs border border-slate-100 dark:border-slate-800 p-5 transition-colors">
            <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-3">1. காலவரம்பு (Select Period)</h3>
            <div className="space-y-3">
              <div>
                <select
                  value={period}
                  onChange={(e) => setPeriod(e.target.value as any)}
                  className="block w-full border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-800 dark:text-slate-150 bg-slate-50 dark:bg-slate-800"
                  style={{ backgroundColor: "#f1a3a3" }}
                >
                  <option value="monthly">மாதாந்திர அறிக்கை</option>
                  <option value="quarterly">காலாண்டு அறிக்கை</option>
                  <option value="yearly">ஆண்டறிக்கை</option>
                  <option value="custom">தேதி வரம்பு (Custom Range)</option>
                </select>
              </div>

              {/* Dynamic Filter Details */}
              {period === "monthly" && (
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-50 dark:border-slate-850">
                  <select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="block w-full border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-850"
                    style={{ backgroundColor: "#fbb9b9" }}
                  >
                    {monthsMap.map((m) => (
                      <option key={m.value} value={m.value}>
                        {m.label.split(" ")[0]}
                      </option>
                    ))}
                  </select>
                  <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="block w-full border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-850"
                    style={{ backgroundColor: "#f4b0b0" }}
                  >
                    {yearsList.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {period === "quarterly" && (
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-50 dark:border-slate-850">
                  <select
                    value={selectedQuarter}
                    onChange={(e) => setSelectedQuarter(e.target.value as any)}
                    className="block w-full border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-850"
                    style={{ backgroundColor: "#fbb9b9" }}
                  >
                    <option value="Q1">Q1 Quarter</option>
                    <option value="Q2">Q2 Quarter</option>
                    <option value="Q3">Q3 Quarter</option>
                    <option value="Q4">Q4 Quarter</option>
                  </select>
                  <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="block w-full border border-slate-200 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-850"
                    style={{ backgroundColor: "#f4b0b0" }}
                  >
                    {yearsList.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {period === "yearly" && (
                <div className="pt-2 border-t border-slate-50 dark:border-slate-850">
                  <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="block w-full border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-850"
                    style={{ backgroundColor: "#fbb9b9" }}
                  >
                    {yearsList.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {period === "custom" && (
                <div className="space-y-2 pt-2 border-t border-slate-50 dark:border-slate-850">
                  <div>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold uppercase block">இருந்து (From)</span>
                    <input
                      type="date"
                      value={fromDate}
                      onChange={(e) => setFromDate(e.target.value)}
                      className="block w-full border border-slate-250 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-150 bg-white dark:bg-slate-850 mt-0.5"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-semibold uppercase block">வரை (To)</span>
                    <input
                      type="date"
                      value={toDate}
                      onChange={(e) => setToDate(e.target.value)}
                      className="block w-full border border-slate-250 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-150 bg-white dark:bg-slate-850 mt-0.5"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Categories select checkboxes */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xs border border-slate-100 dark:border-slate-800 p-5 transition-colors">
            <div className="flex justify-between items-center mb-3 align-middle">
              <h3 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                2. வகைகள் (Select Categories)
              </h3>
              <div className="flex space-x-2 text-[10px] font-bold text-[#1D9E75] dark:text-[#10b981]">
                <button type="button" onClick={handleSelectAll} className="hover:underline cursor-pointer">அனைத்தும்</button>
                <span className="text-slate-350 dark:text-slate-600">|</span>
                <button type="button" onClick={handleDeselectAll} className="hover:underline text-rose-600 dark:text-rose-450 cursor-pointer">நீக்கு</button>
              </div>
            </div>

            {availableCategories.length === 0 ? (
              <p className="text-xs text-slate-400 dark:text-slate-550 text-center py-4">தற்போது எந்த வகைகளும் இல்லை.</p>
            ) : (
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                {availableCategories.map((catName) => {
                  const isChecked = selectedCategories.includes(catName);
                  return (
                    <label
                      key={catName}
                      className="flex items-center space-x-3 text-sm font-semibold text-slate-705 dark:text-slate-300 cursor-pointer select-none group"
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => handleToggleCategory(catName)}
                        className="sr-only"
                      />
                      <div
                        className={`w-5 h-5 rounded-md flex items-center justify-center border transition-all ${
                          isChecked
                            ? "bg-[#1D9E75] border-transparent text-white scale-102"
                            : "border-slate-300 dark:border-slate-700 group-hover:border-[#1D9E75] dark:group-hover:border-[#10b981]"
                        }`}
                      >
                        {isChecked && <Check className="h-3.5 w-3.5 stroke-[4px]" />}
                      </div>
                      <span className={isChecked ? "text-slate-900 dark:text-slate-100 transition-colors" : "text-slate-500 dark:text-slate-450 transition-colors"}>
                        {catName}
                      </span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Filtered summaries list cards & PDF option */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xs border border-slate-100 dark:border-slate-800 p-5 transition-colors">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">வகை வாரியான கூட்டுத் தொகை</h3>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-0.5">Summary metrics and counts by category</p>
              </div>
              <button
                type="button"
                onClick={generateCategoryPDF}
                className="inline-flex items-center self-start px-3 py-2 border border-transparent rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-colors cursor-pointer"
              >
                <FileDown className="h-4 w-4 mr-1" />
                அறிக்கை PDF பதிவிறக்கம்
              </button>
            </div>

            {categorySummaries.length === 0 || selectedCategories.length === 0 ? (
              <div className="text-center py-16">
                <FolderOpen className="mx-auto h-12 w-12 text-slate-350 dark:text-slate-600 mb-3" />
                <p className="text-sm font-bold text-slate-600 dark:text-slate-400">வகைகளை தேர்வு செய்யவும்.</p>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                  இடதுபுற முனையிலுள்ள தலைப்புகளைத் தேர்ந்தெடுத்து ஆய்வு செய்யவும்.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {categorySummaries.map((sum, index) => {
                  const isIncome = sum.type === "income";
                  let cardStyle: React.CSSProperties = {};
                  if (index === 0) cardStyle = { backgroundColor: "#ff8dc6" };
                  else if (index === 1) cardStyle = { backgroundColor: "#eb8dc3" };
                  else if (index === 2) cardStyle = { backgroundColor: "#fb6cd7" };
                  else if (index === 3) cardStyle = { backgroundColor: "#ef85d8" };
                  return (
                    <div
                      key={sum.name}
                      className="p-4 rounded-xl bg-slate-50/50 dark:bg-slate-850/40 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-150 dark:border-slate-800 transition-all hover:shadow-xs flex flex-col justify-between"
                      style={cardStyle}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-slate-800 dark:text-slate-200 text-ellipsis overflow-hidden whitespace-nowrap transition-colors">
                          {sum.name}
                        </span>
                        <span
                          className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                            isIncome ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400" : "bg-rose-100 dark:bg-rose-950/40 text-rose-800 dark:text-rose-400"
                          }`}
                        >
                          {isIncome ? "வரவு" : "செலவு"}
                        </span>
                      </div>

                      <div className="mt-4">
                        <p
                          className={`text-xl font-extrabold ${
                            isIncome ? "text-emerald-600 dark:text-emerald-400" : "text-[#DC2626] dark:text-rose-400"
                          }`}
                        >
                          {formatCurrency(sum.total)}
                        </p>
                        <div className="flex justify-between items-center text-[10px] text-slate-400 dark:text-slate-500 mt-1 font-semibold">
                          <span>பதிவுகளின் எண்ணிக்கை:</span>
                          <span className="text-slate-600 dark:text-slate-300 font-bold bg-slate-200/50 dark:bg-slate-800 px-2 py-0.5 rounded-md transition-colors">
                            {sum.count} பதிவுகள்
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Table list corresponding to this selection */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 p-5 shadow-xs transition-colors">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-3">
              வகை வடிகட்டப்பட்ட பதிவுகள் ({filteredEntries.length})
            </h3>

            {filteredEntries.length === 0 ? (
              <p className="text-xs text-slate-400 dark:text-slate-500 py-6 text-center">தேர்ந்தெடுக்கப்பட்ட விவரங்களில் எந்த பதிவுகளும் இல்லை.</p>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-100 dark:border-slate-800">
                <table className="min-w-full divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-850 font-bold text-slate-500 dark:text-slate-400">
                    <tr>
                      <th className="px-3 py-2 text-left">தேதி</th>
                      <th className="px-3 py-2 text-left">வகை</th>
                      <th className="px-3 py-2 text-right">வருமானம் (₹)</th>
                      <th className="px-3 py-2 text-right">செலவு (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-slate-900 divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredEntries.map((entry) => (
                      <tr key={entry.id} className="hover:bg-slate-50/20 dark:hover:bg-slate-800/25 transition-colors">
                        <td className="px-3 py-2 text-slate-550 dark:text-slate-400 font-mono">
                          {entry.date}
                        </td>
                        <td className="px-3 py-2 font-semibold text-slate-800 dark:text-slate-200">
                          {entry.category}
                        </td>
                        <td className="px-3 py-2 text-right font-extrabold text-[#1D9E75] dark:text-[#10b981]">
                          {entry.type === "income" ? formatCurrency(entry.amount) : "—"}
                        </td>
                        <td className="px-3 py-2 text-right font-extrabold text-rose-600 dark:text-rose-450">
                          {entry.type === "expense" ? formatCurrency(entry.amount) : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* PERFECT PIXEL HIGH-FIDELITY PRIVATE CATEGORY PDF TEMPLATE */}
      {isGeneratingPDF && (
        <div
          id="category-pdf-template"
          style={{
            position: "absolute",
            left: "-9999px",
            top: "0px",
            width: "800px",
            boxSizing: "border-box",
            padding: "45px 50px",
            background: "#ffffff",
            color: "#1e293b",
            fontSize: "14px",
          }}
          className="font-sans"
        >
          {/* Main Content Layout */}
          <div className="w-full">
            {/* Elegant Header Accent Brand Band */}
            <div className="h-2 bg-[#1D9E75] w-full rounded-t-lg mb-6"></div>

            {/* Split Header Info Details */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-2xl font-extrabold text-[#0f172a] tracking-tight">{masjidName}</h1>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mt-1">{masjidArea}</p>
                <div className="mt-4 flex items-center space-x-2 text-xs text-slate-400">
                  <span className="font-bold">அறிக்கை தேதி (Date):</span>
                  <span>{new Date().toLocaleDateString("en-IN", { day: '2-digit', month: '2-digit', year: 'numeric' })}</span>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-block bg-[#E6F5F0] text-[#1D9E75] font-extrabold text-[10px] uppercase px-3 py-1 rounded-full mb-1">
                  CATEGORY ANALYSIS
                </span>
                <p className="text-lg font-extrabold text-slate-800">வகை வாரியான நிதி அறிக்கை</p>
                <p className="text-xs text-slate-400 font-bold mt-1">காலவரம்பு: {periodDisplayName}</p>
              </div>
            </div>

            {/* Subtle Divider Rule Line */}
            <div className="border-b border-slate-200 mb-8"></div>

            {/* Section: Category Metrics Grid */}
            <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-4">
              Category Totals Summary / வகைகளின் வாரியான ஒப்பீடு
            </h3>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              {categorySummaries.map((sum) => {
                const isIncome = sum.type === "income";
                return (
                  <div
                    key={sum.name}
                    style={{ borderColor: '#e2e8f0', borderWidth: '1px', borderStyle: 'solid' }}
                    className="p-4 rounded-xl bg-[#FDFDFD] flex justify-between items-center"
                  >
                    <div>
                      <p className="font-bold text-slate-800 text-sm">{sum.name}</p>
                      <p className="text-[10px] text-slate-400 font-semibold mt-1">
                        பதிவுகளின் எண்ணிக்கை (Count): {sum.count}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className={`text-base font-extrabold ${isIncome ? "text-[#10B981]" : "text-[#EF4444]"}`}>
                        {formatCurrency(sum.total)}
                      </p>
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${isIncome ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"}`}>
                        {isIncome ? "வரவு (Income)" : "செலவு (Expense)"}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Ledger Itemisation Block Header */}
            <div className="flex justify-between items-center bg-[#F8FAFC] border-t border-b border-slate-200 px-4 py-3 mb-4">
              <span className="text-xs font-extrabold text-slate-500 uppercase tracking-widest">
                ITEMIZED DETAILS / வகைப்படுத்தப்பட்ட பதிவுகளின் பட்டியல்
              </span>
              <span className="text-xs font-bold text-[#1D9E75]">
                {filteredEntries.length} பதிவுகள்
              </span>
            </div>

            {/* Printed Ledger Table */}
            {filteredEntries.length === 0 ? (
              <p className="text-center text-slate-400 py-12 text-sm italic">
                தேர்ந்தெடுக்கப்பட்ட விவரங்களில் எந்த பதிவுகளும் இல்லை.
              </p>
            ) : (
              <div style={{ borderColor: '#f1f5f9', borderWidth: '1px', borderStyle: 'solid' }} className="rounded-xl overflow-hidden mb-12">
                <table className="min-w-full divide-y divide-[#f1f5f9] text-[13px]">
                  <thead className="bg-[#F8FAFC]">
                    <tr>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-left font-bold text-xs uppercase tracking-wider">தேதி</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-left font-bold text-xs uppercase tracking-wider">வகை</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-right font-bold text-xs uppercase tracking-wider">வருமானம் (₹)</th>
                      <th scope="col" style={{ color: '#64748b' }} className="px-5 py-3.5 text-right font-bold text-xs uppercase tracking-wider">செலவு (₹)</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-[#f1f5f9]">
                    {filteredEntries.map((entry, idx) => (
                      <tr key={entry.id} className={idx % 2 === 0 ? "bg-white" : "bg-[#FCFDFE]"}>
                        <td className="px-5 py-3.5 whitespace-nowrap text-slate-500 font-mono text-xs">{entry.date}</td>
                        <td className="px-5 py-3.5 whitespace-nowrap font-semibold text-slate-800">{entry.category}</td>
                        <td className="px-5 py-3.5 whitespace-nowrap text-right font-extrabold text-[#10B981]">
                          {entry.type === "income" ? formatCurrency(entry.amount) : "—"}
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap text-right font-extrabold text-[#EF4444]">
                          {entry.type === "expense" ? formatCurrency(entry.amount) : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Official Audit Closure / Signature Sign-off Lines */}
            <div className="grid grid-cols-2 gap-12 mt-16 pt-12 border-t border-slate-100 mb-8" style={{ pageBreakBefore: 'avoid' }}>
              <div className="text-center">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">தயாரித்தவர் (Prepared By)</p>
                <div className="mt-14 border-b border-dashed border-slate-300 mx-10"></div>
                <p className="text-[11px] font-bold text-slate-400 mt-2">பள்ளிவாசல் பொருளாளர் / Treasurer</p>
              </div>
              <div className="text-center">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">ஒப்புதல் அளித்தவர் (Approved By)</p>
                <div className="mt-14 border-b border-dashed border-slate-300 mx-10"></div>
                <p className="text-[11px] font-bold text-slate-400 mt-2">பள்ளிவாசல் தலைவர் / President</p>
               </div>
            </div>

            {/* Watermark Branding */}
            <div className="text-center text-[10px] text-slate-300 font-bold tracking-widest mt-12 uppercase">
              MASJID ACCOUNTS OFFICIAL CATEGORY ANALYSIS
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
